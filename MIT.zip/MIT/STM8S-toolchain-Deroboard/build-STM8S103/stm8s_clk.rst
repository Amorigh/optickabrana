                                      1 .module stm8s_clk
                                      2 .optsdcc -mstm8
                                      3 .globl _HSIDivFactor
                                      4 .globl _CLK_HSIPrescalerConfig
                                      5 .globl _CLK_GetClockFreq
                                      6 .area DATA
                                      7 .area INITIALIZED
                                      8 .area DABS (ABS)
                                      9 .area HOME
                                     10 .area GSINIT
                                     11 .area GSFINAL
                                     12 .area CONST
                                     13 .area INITIALIZER
                                     14 .area CODE
                                     15 .area HOME
                                     16 .area GSINIT
                                     17 .area GSFINAL
                                     18 .area GSINIT
                                     19 .area HOME
                                     20 .area HOME
                                     21 .area CODE
      008786                         22 _CLK_HSIPrescalerConfig:
      008786 C6 50 C6         [ 1]   23 ld	a, 0x50c6
      008789 A4 E7            [ 1]   24 and	a, #0xe7
      00878B C7 50 C6         [ 1]   25 ld	0x50c6, a
      00878E C6 50 C6         [ 1]   26 ld	a, 0x50c6
      008791 1A 03            [ 1]   27 or	a, (0x03, sp)
      008793 C7 50 C6         [ 1]   28 ld	0x50c6, a
      008796                         29 00101$:
      008796 81               [ 4]   30 ret
      008797                         31 _CLK_GetClockFreq:
      008797 52 04            [ 2]   32 sub	sp, #4
      008799 C6 50 C3         [ 1]   33 ld	a, 0x50c3
      00879C 6B 04            [ 1]   34 ld	(0x04, sp), a
      00879E 7B 04            [ 1]   35 ld	a, (0x04, sp)
      0087A0 A1 E1            [ 1]   36 cp	a, #0xe1
      0087A2 26 03            [ 1]   37 jrne	00120$
      0087A4 CC 87 AA         [ 2]   38 jp	00121$
      0087A7                         39 00120$:
      0087A7 CC 87 D1         [ 2]   40 jp	00105$
      0087AA                         41 00121$:
      0087AA C6 50 C6         [ 1]   42 ld	a, 0x50c6
      0087AD A4 18            [ 1]   43 and	a, #0x18
      0087AF 44               [ 1]   44 srl	a
      0087B0 44               [ 1]   45 srl	a
      0087B1 44               [ 1]   46 srl	a
      0087B2 5F               [ 1]   47 clrw	x
      0087B3 97               [ 1]   48 ld	xl, a
      0087B4 1C 80 C9         [ 2]   49 addw	x, #(_HSIDivFactor + 0)
      0087B7 F6               [ 1]   50 ld	a, (x)
      0087B8 5F               [ 1]   51 clrw	x
      0087B9 97               [ 1]   52 ld	xl, a
      0087BA 90 5F            [ 1]   53 clrw	y
      0087BC 89               [ 2]   54 pushw	x
      0087BD 90 89            [ 2]   55 pushw	y
      0087BF 4B 00            [ 1]   56 push	#0x00
      0087C1 4B 24            [ 1]   57 push	#0x24
      0087C3 4B F4            [ 1]   58 push	#0xf4
      0087C5 4B 00            [ 1]   59 push	#0x00
      0087C7 CD 8C 67         [ 4]   60 call	__divulong
      0087CA 5B 08            [ 2]   61 addw	sp, #8
      0087CC 1F 03            [ 2]   62 ldw	(0x03, sp), x
      0087CE CC 87 F2         [ 2]   63 jp	00106$
      0087D1                         64 00105$:
      0087D1 7B 04            [ 1]   65 ld	a, (0x04, sp)
      0087D3 A1 D2            [ 1]   66 cp	a, #0xd2
      0087D5 26 03            [ 1]   67 jrne	00123$
      0087D7 CC 87 DD         [ 2]   68 jp	00124$
      0087DA                         69 00123$:
      0087DA CC 87 E9         [ 2]   70 jp	00102$
      0087DD                         71 00124$:
      0087DD AE F4 00         [ 2]   72 ldw	x, #0xf400
      0087E0 1F 03            [ 2]   73 ldw	(0x03, sp), x
      0087E2 90 AE 00 01      [ 2]   74 ldw	y, #0x0001
      0087E6 CC 87 F2         [ 2]   75 jp	00106$
      0087E9                         76 00102$:
      0087E9 AE 24 00         [ 2]   77 ldw	x, #0x2400
      0087EC 1F 03            [ 2]   78 ldw	(0x03, sp), x
      0087EE 90 AE 00 F4      [ 2]   79 ldw	y, #0x00f4
      0087F2                         80 00106$:
      0087F2 1E 03            [ 2]   81 ldw	x, (0x03, sp)
      0087F4                         82 00107$:
      0087F4 5B 04            [ 2]   83 addw	sp, #4
      0087F6 81               [ 4]   84 ret
                                     85 .area CODE
                                     86 .area CONST
      0080C9                         87 _HSIDivFactor:
      0080C9 01                      88 .db #0x01	; 1
      0080CA 02                      89 .db #0x02	; 2
      0080CB 04                      90 .db #0x04	; 4
      0080CC 08                      91 .db #0x08	; 8
                                     92 .area INITIALIZER
                                     93 .area CABS (ABS)
