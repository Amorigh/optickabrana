                                      1 .module milis
                                      2 .optsdcc -mstm8
                                      3 .globl _TIM4_ClearFlag
                                      4 .globl _TIM4_ITConfig
                                      5 .globl _TIM4_Cmd
                                      6 .globl _TIM4_TimeBaseInit
                                      7 .globl _ITC_SetSoftwarePriority
                                      8 .globl _miliseconds
                                      9 .globl _milis
                                     10 .globl _init_milis
                                     11 .globl _TIM4_UPD_OVF_IRQHandler
                                     12 .area DATA
                                     13 .area INITIALIZED
      00007B                         14 _miliseconds::
      00007B                         15 .ds 4
                                     16 .area DABS (ABS)
                                     17 .area HOME
                                     18 .area GSINIT
                                     19 .area GSFINAL
                                     20 .area CONST
                                     21 .area INITIALIZER
                                     22 .area CODE
                                     23 .area HOME
                                     24 .area GSINIT
                                     25 .area GSFINAL
                                     26 .area GSINIT
                                     27 .area HOME
                                     28 .area HOME
                                     29 .area CODE
      00867B                         30 _milis:
      00867B 52 04            [ 2]   31 sub	sp, #4
      00867D 4B 00            [ 1]   32 push	#0x00
      00867F 4B 01            [ 1]   33 push	#0x01
      008681 CD 88 1C         [ 4]   34 call	_TIM4_ITConfig
      008684 85               [ 2]   35 popw	x
      008685 CE 00 7D         [ 2]   36 ldw	x, _miliseconds+2
      008688 90 CE 00 7B      [ 2]   37 ldw	y, _miliseconds+0
      00868C 17 01            [ 2]   38 ldw	(0x01, sp), y
      00868E 89               [ 2]   39 pushw	x
      00868F 4B 01            [ 1]   40 push	#0x01
      008691 4B 01            [ 1]   41 push	#0x01
      008693 CD 88 1C         [ 4]   42 call	_TIM4_ITConfig
      008696 85               [ 2]   43 popw	x
      008697 85               [ 2]   44 popw	x
      008698 16 01            [ 2]   45 ldw	y, (0x01, sp)
      00869A                         46 00101$:
      00869A 5B 04            [ 2]   47 addw	sp, #4
      00869C 81               [ 4]   48 ret
      00869D                         49 _init_milis:
      00869D 4B 7C            [ 1]   50 push	#0x7c
      00869F 4B 07            [ 1]   51 push	#0x07
      0086A1 CD 87 F7         [ 4]   52 call	_TIM4_TimeBaseInit
      0086A4 85               [ 2]   53 popw	x
      0086A5 4B 01            [ 1]   54 push	#0x01
      0086A7 CD 88 4F         [ 4]   55 call	_TIM4_ClearFlag
      0086AA 84               [ 1]   56 pop	a
      0086AB 4B 01            [ 1]   57 push	#0x01
      0086AD 4B 01            [ 1]   58 push	#0x01
      0086AF CD 88 1C         [ 4]   59 call	_TIM4_ITConfig
      0086B2 85               [ 2]   60 popw	x
      0086B3 4B 01            [ 1]   61 push	#0x01
      0086B5 4B 17            [ 1]   62 push	#0x17
      0086B7 CD 88 56         [ 4]   63 call	_ITC_SetSoftwarePriority
      0086BA 85               [ 2]   64 popw	x
      0086BB 9A               [ 1]   65 rim
      0086BC 4B 01            [ 1]   66 push	#0x01
      0086BE CD 88 04         [ 4]   67 call	_TIM4_Cmd
      0086C1 84               [ 1]   68 pop	a
      0086C2                         69 00101$:
      0086C2 81               [ 4]   70 ret
      0086C3                         71 _TIM4_UPD_OVF_IRQHandler:
      0086C3 62               [ 2]   72 div	x, a
      0086C4 4B 01            [ 1]   73 push	#0x01
      0086C6 CD 88 4F         [ 4]   74 call	_TIM4_ClearFlag
      0086C9 84               [ 1]   75 pop	a
      0086CA CE 00 7D         [ 2]   76 ldw	x, _miliseconds+2
      0086CD 90 CE 00 7B      [ 2]   77 ldw	y, _miliseconds+0
      0086D1 5C               [ 1]   78 incw	x
      0086D2 26 02            [ 1]   79 jrne	00103$
      0086D4 90 5C            [ 1]   80 incw	y
      0086D6                         81 00103$:
      0086D6 CF 00 7D         [ 2]   82 ldw	_miliseconds+2, x
      0086D9 90 CF 00 7B      [ 2]   83 ldw	_miliseconds+0, y
      0086DD                         84 00101$:
      0086DD 80               [11]   85 iret
                                     86 .area CODE
                                     87 .area CONST
                                     88 .area INITIALIZER
      0080DC                         89 __xinit__miliseconds:
      0080DC 00 00 00 00             90 .byte #0x00, #0x00, #0x00, #0x00	; 0
                                     91 .area CABS (ABS)
