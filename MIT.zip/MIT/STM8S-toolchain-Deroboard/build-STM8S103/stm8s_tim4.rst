                                      1 .module stm8s_tim4
                                      2 .optsdcc -mstm8
                                      3 .globl _TIM4_TimeBaseInit
                                      4 .globl _TIM4_Cmd
                                      5 .globl _TIM4_ITConfig
                                      6 .globl _TIM4_GetFlagStatus
                                      7 .globl _TIM4_ClearFlag
                                      8 .area DATA
                                      9 .area INITIALIZED
                                     10 .area DABS (ABS)
                                     11 .area HOME
                                     12 .area GSINIT
                                     13 .area GSFINAL
                                     14 .area CONST
                                     15 .area INITIALIZER
                                     16 .area CODE
                                     17 .area HOME
                                     18 .area GSINIT
                                     19 .area GSFINAL
                                     20 .area GSINIT
                                     21 .area HOME
                                     22 .area HOME
                                     23 .area CODE
      0087F7                         24 _TIM4_TimeBaseInit:
      0087F7 AE 53 47         [ 2]   25 ldw	x, #0x5347
      0087FA 7B 03            [ 1]   26 ld	a, (0x03, sp)
      0087FC F7               [ 1]   27 ld	(x), a
      0087FD AE 53 48         [ 2]   28 ldw	x, #0x5348
      008800 7B 04            [ 1]   29 ld	a, (0x04, sp)
      008802 F7               [ 1]   30 ld	(x), a
      008803                         31 00101$:
      008803 81               [ 4]   32 ret
      008804                         33 _TIM4_Cmd:
      008804 C6 53 40         [ 1]   34 ld	a, 0x5340
      008807 0D 03            [ 1]   35 tnz	(0x03, sp)
      008809 26 03            [ 1]   36 jrne	00111$
      00880B CC 88 16         [ 2]   37 jp	00102$
      00880E                         38 00111$:
      00880E AA 01            [ 1]   39 or	a, #0x01
      008810 C7 53 40         [ 1]   40 ld	0x5340, a
      008813 CC 88 1B         [ 2]   41 jp	00104$
      008816                         42 00102$:
      008816 A4 FE            [ 1]   43 and	a, #0xfe
      008818 C7 53 40         [ 1]   44 ld	0x5340, a
      00881B                         45 00104$:
      00881B 81               [ 4]   46 ret
      00881C                         47 _TIM4_ITConfig:
      00881C 88               [ 1]   48 push	a
      00881D C6 53 43         [ 1]   49 ld	a, 0x5343
      008820 0D 05            [ 1]   50 tnz	(0x05, sp)
      008822 26 03            [ 1]   51 jrne	00111$
      008824 CC 88 2F         [ 2]   52 jp	00102$
      008827                         53 00111$:
      008827 1A 04            [ 1]   54 or	a, (0x04, sp)
      008829 C7 53 43         [ 1]   55 ld	0x5343, a
      00882C CC 88 3B         [ 2]   56 jp	00104$
      00882F                         57 00102$:
      00882F 88               [ 1]   58 push	a
      008830 7B 05            [ 1]   59 ld	a, (0x05, sp)
      008832 43               [ 1]   60 cpl	a
      008833 6B 02            [ 1]   61 ld	(0x02, sp), a
      008835 84               [ 1]   62 pop	a
      008836 14 01            [ 1]   63 and	a, (0x01, sp)
      008838 C7 53 43         [ 1]   64 ld	0x5343, a
      00883B                         65 00104$:
      00883B 84               [ 1]   66 pop	a
      00883C 81               [ 4]   67 ret
      00883D                         68 _TIM4_GetFlagStatus:
      00883D C6 53 44         [ 1]   69 ld	a, 0x5344
      008840 14 03            [ 1]   70 and	a, (0x03, sp)
      008842 4D               [ 1]   71 tnz	a
      008843 26 03            [ 1]   72 jrne	00111$
      008845 CC 88 4D         [ 2]   73 jp	00102$
      008848                         74 00111$:
      008848 A6 01            [ 1]   75 ld	a, #0x01
      00884A CC 88 4E         [ 2]   76 jp	00103$
      00884D                         77 00102$:
      00884D 4F               [ 1]   78 clr	a
      00884E                         79 00103$:
      00884E                         80 00104$:
      00884E 81               [ 4]   81 ret
      00884F                         82 _TIM4_ClearFlag:
      00884F 7B 03            [ 1]   83 ld	a, (0x03, sp)
      008851 43               [ 1]   84 cpl	a
      008852 C7 53 44         [ 1]   85 ld	0x5344, a
      008855                         86 00101$:
      008855 81               [ 4]   87 ret
                                     88 .area CODE
                                     89 .area CONST
                                     90 .area INITIALIZER
                                     91 .area CABS (ABS)
