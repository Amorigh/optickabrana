                                      1 .module LCD_I2C
                                      2 .optsdcc -mstm8
                                      3 .globl _delay_us
                                      4 .globl _delay_ms
                                      5 .globl _I2C_GetFlagStatus
                                      6 .globl _I2C_CheckEvent
                                      7 .globl _I2C_SendData
                                      8 .globl _I2C_Send7bitAddress
                                      9 .globl _I2C_GenerateSTOP
                                     10 .globl _I2C_GenerateSTART
                                     11 .globl _I2C_Cmd
                                     12 .globl _I2C_Init
                                     13 .globl _I2C_DeInit
                                     14 .globl _GPIO_Init
                                     15 .globl _CLK_GetClockFreq
                                     16 .globl __lcd_i2c_displaymode
                                     17 .globl __lcd_i2c_displaycontrol
                                     18 .globl __lcd_i2c_displayfunction
                                     19 .globl __lcd_i2c_backlight
                                     20 .globl __lcd_i2c_rows
                                     21 .globl __lcd_i2c_cols
                                     22 .globl __lcd_i2c_address
                                     23 .globl _LCD_I2C_Init
                                     24 .globl _LCD_I2C_Write
                                     25 .globl _LCD_I2C_ExpanderWrite
                                     26 .globl _LCD_I2C_Write4Bits
                                     27 .globl _LCD_I2C_PulseEnable
                                     28 .globl _LCD_I2C_Command
                                     29 .globl _LCD_I2C_Send
                                     30 .globl _LCD_I2C_Display
                                     31 .globl _LCD_I2C_Clear
                                     32 .globl _LCD_I2C_Home
                                     33 .globl _LCD_I2C_SetCursor
                                     34 .globl _LCD_I2C_Print
                                     35 .area DATA
      000001                         36 __lcd_i2c_address::
      000001                         37 .ds 1
      000002                         38 __lcd_i2c_cols::
      000002                         39 .ds 1
      000003                         40 __lcd_i2c_rows::
      000003                         41 .ds 1
      000004                         42 __lcd_i2c_backlight::
      000004                         43 .ds 1
      000005                         44 __lcd_i2c_displayfunction::
      000005                         45 .ds 1
      000006                         46 __lcd_i2c_displaycontrol::
      000006                         47 .ds 1
      000007                         48 __lcd_i2c_displaymode::
      000007                         49 .ds 1
                                     50 .area INITIALIZED
                                     51 .area DABS (ABS)
                                     52 .area HOME
                                     53 .area GSINIT
                                     54 .area GSFINAL
                                     55 .area CONST
                                     56 .area INITIALIZER
                                     57 .area CODE
                                     58 .area HOME
                                     59 .area GSINIT
                                     60 .area GSFINAL
                                     61 .area GSINIT
                                     62 .area HOME
                                     63 .area HOME
                                     64 .area CODE
      0081BD                         65 _LCD_I2C_Init:
      0081BD 7B 03            [ 1]   66 ld	a, (0x03, sp)
      0081BF C7 00 01         [ 1]   67 ld	__lcd_i2c_address+0, a
      0081C2 72 58 00 01      [ 1]   68 sll	__lcd_i2c_address+0
      0081C6 7B 04            [ 1]   69 ld	a, (0x04, sp)
      0081C8 C7 00 02         [ 1]   70 ld	__lcd_i2c_cols+0, a
      0081CB 7B 05            [ 1]   71 ld	a, (0x05, sp)
      0081CD C7 00 03         [ 1]   72 ld	__lcd_i2c_rows+0, a
      0081D0 35 08 00 04      [ 1]   73 mov	__lcd_i2c_backlight+0, #0x08
      0081D4 35 08 00 05      [ 1]   74 mov	__lcd_i2c_displayfunction+0, #0x08
      0081D8 4B F0            [ 1]   75 push	#0xf0
      0081DA 4B 20            [ 1]   76 push	#0x20
      0081DC 4B 0A            [ 1]   77 push	#0x0a
      0081DE 4B 50            [ 1]   78 push	#0x50
      0081E0 CD 86 F1         [ 4]   79 call	_GPIO_Init
      0081E3 5B 04            [ 2]   80 addw	sp, #4
      0081E5 4B F0            [ 1]   81 push	#0xf0
      0081E7 4B 10            [ 1]   82 push	#0x10
      0081E9 4B 0A            [ 1]   83 push	#0x0a
      0081EB 4B 50            [ 1]   84 push	#0x50
      0081ED CD 86 F1         [ 4]   85 call	_GPIO_Init
      0081F0 5B 04            [ 2]   86 addw	sp, #4
      0081F2 CD 89 46         [ 4]   87 call	_I2C_DeInit
      0081F5 CD 87 97         [ 4]   88 call	_CLK_GetClockFreq
      0081F8 4B 40            [ 1]   89 push	#0x40
      0081FA 4B 42            [ 1]   90 push	#0x42
      0081FC 4B 0F            [ 1]   91 push	#0x0f
      0081FE 4B 00            [ 1]   92 push	#0x00
      008200 89               [ 2]   93 pushw	x
      008201 90 89            [ 2]   94 pushw	y
      008203 CD 8C 67         [ 4]   95 call	__divulong
      008206 5B 08            [ 2]   96 addw	sp, #8
      008208 9F               [ 1]   97 ld	a, xl
      008209 5F               [ 1]   98 clrw	x
      00820A 41               [ 1]   99 exg	a, xl
      00820B C6 00 01         [ 1]  100 ld	a, __lcd_i2c_address+0
      00820E 41               [ 1]  101 exg	a, xl
      00820F 88               [ 1]  102 push	a
      008210 4B 00            [ 1]  103 push	#0x00
      008212 4B 01            [ 1]  104 push	#0x01
      008214 4B 00            [ 1]  105 push	#0x00
      008216 89               [ 2]  106 pushw	x
      008217 4B A0            [ 1]  107 push	#0xa0
      008219 4B 86            [ 1]  108 push	#0x86
      00821B 4B 01            [ 1]  109 push	#0x01
      00821D 4B 00            [ 1]  110 push	#0x00
      00821F CD 89 6B         [ 4]  111 call	_I2C_Init
      008222 5B 0A            [ 2]  112 addw	sp, #10
      008224 4B 01            [ 1]  113 push	#0x01
      008226 CD 8A A7         [ 4]  114 call	_I2C_Cmd
      008229 84               [ 1]  115 pop	a
      00822A 4B 32            [ 1]  116 push	#0x32
      00822C 5F               [ 1]  117 clrw	x
      00822D 89               [ 2]  118 pushw	x
      00822E 4B 00            [ 1]  119 push	#0x00
      008230 CD 80 E0         [ 4]  120 call	_delay_ms
      008233 5B 04            [ 2]  121 addw	sp, #4
      008235 3B 00 04         [ 1]  122 push	__lcd_i2c_backlight+0
      008238 CD 82 F7         [ 4]  123 call	_LCD_I2C_ExpanderWrite
      00823B 84               [ 1]  124 pop	a
      00823C 4B E8            [ 1]  125 push	#0xe8
      00823E 4B 03            [ 1]  126 push	#0x03
      008240 5F               [ 1]  127 clrw	x
      008241 89               [ 2]  128 pushw	x
      008242 CD 80 E0         [ 4]  129 call	_delay_ms
      008245 5B 04            [ 2]  130 addw	sp, #4
      008247 4B 30            [ 1]  131 push	#0x30
      008249 CD 83 05         [ 4]  132 call	_LCD_I2C_Write4Bits
      00824C 84               [ 1]  133 pop	a
      00824D 4B 94            [ 1]  134 push	#0x94
      00824F 4B 11            [ 1]  135 push	#0x11
      008251 5F               [ 1]  136 clrw	x
      008252 89               [ 2]  137 pushw	x
      008253 CD 81 46         [ 4]  138 call	_delay_us
      008256 5B 04            [ 2]  139 addw	sp, #4
      008258 4B 30            [ 1]  140 push	#0x30
      00825A CD 83 05         [ 4]  141 call	_LCD_I2C_Write4Bits
      00825D 84               [ 1]  142 pop	a
      00825E 4B 94            [ 1]  143 push	#0x94
      008260 4B 11            [ 1]  144 push	#0x11
      008262 5F               [ 1]  145 clrw	x
      008263 89               [ 2]  146 pushw	x
      008264 CD 81 46         [ 4]  147 call	_delay_us
      008267 5B 04            [ 2]  148 addw	sp, #4
      008269 4B 30            [ 1]  149 push	#0x30
      00826B CD 83 05         [ 4]  150 call	_LCD_I2C_Write4Bits
      00826E 84               [ 1]  151 pop	a
      00826F 4B 96            [ 1]  152 push	#0x96
      008271 5F               [ 1]  153 clrw	x
      008272 89               [ 2]  154 pushw	x
      008273 4B 00            [ 1]  155 push	#0x00
      008275 CD 81 46         [ 4]  156 call	_delay_us
      008278 5B 04            [ 2]  157 addw	sp, #4
      00827A 4B 20            [ 1]  158 push	#0x20
      00827C CD 83 05         [ 4]  159 call	_LCD_I2C_Write4Bits
      00827F 84               [ 1]  160 pop	a
      008280 C6 00 05         [ 1]  161 ld	a, __lcd_i2c_displayfunction+0
      008283 AA 20            [ 1]  162 or	a, #0x20
      008285 88               [ 1]  163 push	a
      008286 CD 83 43         [ 4]  164 call	_LCD_I2C_Command
      008289 84               [ 1]  165 pop	a
      00828A 35 04 00 06      [ 1]  166 mov	__lcd_i2c_displaycontrol+0, #0x04
      00828E CD 83 6F         [ 4]  167 call	_LCD_I2C_Display
      008291 CD 83 82         [ 4]  168 call	_LCD_I2C_Clear
      008294 35 02 00 07      [ 1]  169 mov	__lcd_i2c_displaymode+0, #0x02
      008298 4B 06            [ 1]  170 push	#0x06
      00829A CD 83 43         [ 4]  171 call	_LCD_I2C_Command
      00829D 84               [ 1]  172 pop	a
      00829E CC 83 94         [ 2]  173 jp	_LCD_I2C_Home
      0082A1                        174 00101$:
      0082A1 81               [ 4]  175 ret
      0082A2                        176 _LCD_I2C_Write:
      0082A2                        177 00101$:
      0082A2 4B 02            [ 1]  178 push	#0x02
      0082A4 4B 03            [ 1]  179 push	#0x03
      0082A6 CD 8B 8D         [ 4]  180 call	_I2C_GetFlagStatus
      0082A9 85               [ 2]  181 popw	x
      0082AA 4D               [ 1]  182 tnz	a
      0082AB 27 03            [ 1]  183 jreq	00155$
      0082AD CC 82 A2         [ 2]  184 jp	00101$
      0082B0                        185 00155$:
      0082B0 4B 01            [ 1]  186 push	#0x01
      0082B2 CD 8A BF         [ 4]  187 call	_I2C_GenerateSTART
      0082B5 84               [ 1]  188 pop	a
      0082B6                        189 00104$:
      0082B6 4B 01            [ 1]  190 push	#0x01
      0082B8 4B 03            [ 1]  191 push	#0x03
      0082BA CD 8B 37         [ 4]  192 call	_I2C_CheckEvent
      0082BD 85               [ 2]  193 popw	x
      0082BE 4D               [ 1]  194 tnz	a
      0082BF 26 03            [ 1]  195 jrne	00156$
      0082C1 CC 82 B6         [ 2]  196 jp	00104$
      0082C4                        197 00156$:
      0082C4 4B 00            [ 1]  198 push	#0x00
      0082C6 7B 04            [ 1]  199 ld	a, (0x04, sp)
      0082C8 88               [ 1]  200 push	a
      0082C9 CD 8B 24         [ 4]  201 call	_I2C_Send7bitAddress
      0082CC 85               [ 2]  202 popw	x
      0082CD                        203 00107$:
      0082CD 4B 82            [ 1]  204 push	#0x82
      0082CF 4B 07            [ 1]  205 push	#0x07
      0082D1 CD 8B 37         [ 4]  206 call	_I2C_CheckEvent
      0082D4 85               [ 2]  207 popw	x
      0082D5 4D               [ 1]  208 tnz	a
      0082D6 26 03            [ 1]  209 jrne	00157$
      0082D8 CC 82 CD         [ 2]  210 jp	00107$
      0082DB                        211 00157$:
      0082DB 7B 04            [ 1]  212 ld	a, (0x04, sp)
      0082DD 88               [ 1]  213 push	a
      0082DE CD 8B 30         [ 4]  214 call	_I2C_SendData
      0082E1 84               [ 1]  215 pop	a
      0082E2                        216 00110$:
      0082E2 4B 84            [ 1]  217 push	#0x84
      0082E4 4B 07            [ 1]  218 push	#0x07
      0082E6 CD 8B 37         [ 4]  219 call	_I2C_CheckEvent
      0082E9 85               [ 2]  220 popw	x
      0082EA 4D               [ 1]  221 tnz	a
      0082EB 26 03            [ 1]  222 jrne	00158$
      0082ED CC 82 E2         [ 2]  223 jp	00110$
      0082F0                        224 00158$:
      0082F0 4B 01            [ 1]  225 push	#0x01
      0082F2 CD 8A D7         [ 4]  226 call	_I2C_GenerateSTOP
      0082F5 84               [ 1]  227 pop	a
      0082F6                        228 00113$:
      0082F6 81               [ 4]  229 ret
      0082F7                        230 _LCD_I2C_ExpanderWrite:
      0082F7 7B 03            [ 1]  231 ld	a, (0x03, sp)
      0082F9 CA 00 04         [ 1]  232 or	a, __lcd_i2c_backlight+0
      0082FC 88               [ 1]  233 push	a
      0082FD 3B 00 01         [ 1]  234 push	__lcd_i2c_address+0
      008300 CD 82 A2         [ 4]  235 call	_LCD_I2C_Write
      008303 85               [ 2]  236 popw	x
      008304                        237 00101$:
      008304 81               [ 4]  238 ret
      008305                        239 _LCD_I2C_Write4Bits:
      008305 7B 03            [ 1]  240 ld	a, (0x03, sp)
      008307 88               [ 1]  241 push	a
      008308 CD 82 F7         [ 4]  242 call	_LCD_I2C_ExpanderWrite
      00830B 84               [ 1]  243 pop	a
      00830C 7B 03            [ 1]  244 ld	a, (0x03, sp)
      00830E 88               [ 1]  245 push	a
      00830F CD 83 14         [ 4]  246 call	_LCD_I2C_PulseEnable
      008312 84               [ 1]  247 pop	a
      008313                        248 00101$:
      008313 81               [ 4]  249 ret
      008314                        250 _LCD_I2C_PulseEnable:
      008314 88               [ 1]  251 push	a
      008315 7B 04            [ 1]  252 ld	a, (0x04, sp)
      008317 6B 01            [ 1]  253 ld	(0x01, sp), a
      008319 7B 01            [ 1]  254 ld	a, (0x01, sp)
      00831B AA 04            [ 1]  255 or	a, #0x04
      00831D 88               [ 1]  256 push	a
      00831E CD 82 F7         [ 4]  257 call	_LCD_I2C_ExpanderWrite
      008321 84               [ 1]  258 pop	a
      008322 4B 01            [ 1]  259 push	#0x01
      008324 5F               [ 1]  260 clrw	x
      008325 89               [ 2]  261 pushw	x
      008326 4B 00            [ 1]  262 push	#0x00
      008328 CD 81 46         [ 4]  263 call	_delay_us
      00832B 5B 04            [ 2]  264 addw	sp, #4
      00832D 7B 01            [ 1]  265 ld	a, (0x01, sp)
      00832F A4 FB            [ 1]  266 and	a, #0xfb
      008331 88               [ 1]  267 push	a
      008332 CD 82 F7         [ 4]  268 call	_LCD_I2C_ExpanderWrite
      008335 84               [ 1]  269 pop	a
      008336 4B 32            [ 1]  270 push	#0x32
      008338 5F               [ 1]  271 clrw	x
      008339 89               [ 2]  272 pushw	x
      00833A 4B 00            [ 1]  273 push	#0x00
      00833C CD 81 46         [ 4]  274 call	_delay_us
      00833F 5B 04            [ 2]  275 addw	sp, #4
      008341                        276 00101$:
      008341 84               [ 1]  277 pop	a
      008342 81               [ 4]  278 ret
      008343                        279 _LCD_I2C_Command:
      008343 4B 00            [ 1]  280 push	#0x00
      008345 7B 04            [ 1]  281 ld	a, (0x04, sp)
      008347 88               [ 1]  282 push	a
      008348 CD 83 4D         [ 4]  283 call	_LCD_I2C_Send
      00834B 85               [ 2]  284 popw	x
      00834C                        285 00101$:
      00834C 81               [ 4]  286 ret
      00834D                        287 _LCD_I2C_Send:
      00834D 88               [ 1]  288 push	a
      00834E 7B 04            [ 1]  289 ld	a, (0x04, sp)
      008350 88               [ 1]  290 push	a
      008351 A4 F0            [ 1]  291 and	a, #0xf0
      008353 97               [ 1]  292 ld	xl, a
      008354 84               [ 1]  293 pop	a
      008355 4E               [ 1]  294 swap	a
      008356 A4 F0            [ 1]  295 and	a, #0xf0
      008358 A4 F0            [ 1]  296 and	a, #0xf0
      00835A 6B 01            [ 1]  297 ld	(0x01, sp), a
      00835C 9F               [ 1]  298 ld	a, xl
      00835D 1A 05            [ 1]  299 or	a, (0x05, sp)
      00835F 88               [ 1]  300 push	a
      008360 CD 83 05         [ 4]  301 call	_LCD_I2C_Write4Bits
      008363 84               [ 1]  302 pop	a
      008364 7B 01            [ 1]  303 ld	a, (0x01, sp)
      008366 1A 05            [ 1]  304 or	a, (0x05, sp)
      008368 88               [ 1]  305 push	a
      008369 CD 83 05         [ 4]  306 call	_LCD_I2C_Write4Bits
      00836C 84               [ 1]  307 pop	a
      00836D                        308 00101$:
      00836D 84               [ 1]  309 pop	a
      00836E 81               [ 4]  310 ret
      00836F                        311 _LCD_I2C_Display:
      00836F C6 00 06         [ 1]  312 ld	a, __lcd_i2c_displaycontrol+0
      008372 AA 04            [ 1]  313 or	a, #0x04
      008374 C7 00 06         [ 1]  314 ld	__lcd_i2c_displaycontrol+0, a
      008377 C6 00 06         [ 1]  315 ld	a, __lcd_i2c_displaycontrol+0
      00837A AA 08            [ 1]  316 or	a, #0x08
      00837C 88               [ 1]  317 push	a
      00837D CD 83 43         [ 4]  318 call	_LCD_I2C_Command
      008380 84               [ 1]  319 pop	a
      008381                        320 00101$:
      008381 81               [ 4]  321 ret
      008382                        322 _LCD_I2C_Clear:
      008382 4B 01            [ 1]  323 push	#0x01
      008384 CD 83 43         [ 4]  324 call	_LCD_I2C_Command
      008387 84               [ 1]  325 pop	a
      008388 4B D0            [ 1]  326 push	#0xd0
      00838A 4B 07            [ 1]  327 push	#0x07
      00838C 5F               [ 1]  328 clrw	x
      00838D 89               [ 2]  329 pushw	x
      00838E CD 81 46         [ 4]  330 call	_delay_us
      008391 5B 04            [ 2]  331 addw	sp, #4
      008393                        332 00101$:
      008393 81               [ 4]  333 ret
      008394                        334 _LCD_I2C_Home:
      008394 4B 02            [ 1]  335 push	#0x02
      008396 CD 83 43         [ 4]  336 call	_LCD_I2C_Command
      008399 84               [ 1]  337 pop	a
      00839A 4B D0            [ 1]  338 push	#0xd0
      00839C 4B 07            [ 1]  339 push	#0x07
      00839E 5F               [ 1]  340 clrw	x
      00839F 89               [ 2]  341 pushw	x
      0083A0 CD 81 46         [ 4]  342 call	_delay_us
      0083A3 5B 04            [ 2]  343 addw	sp, #4
      0083A5                        344 00101$:
      0083A5 81               [ 4]  345 ret
      0083A6                        346 _LCD_I2C_SetCursor:
      0083A6 52 0A            [ 2]  347 sub	sp, #10
      0083A8 5F               [ 1]  348 clrw	x
      0083A9 1F 01            [ 2]  349 ldw	(0x01, sp), x
      0083AB 96               [ 1]  350 ldw	x, sp
      0083AC 1C 00 03         [ 2]  351 addw	x, #3
      0083AF 90 AE 00 40      [ 2]  352 ldw	y, #0x0040
      0083B3 FF               [ 2]  353 ldw	(x), y
      0083B4 96               [ 1]  354 ldw	x, sp
      0083B5 1C 00 05         [ 2]  355 addw	x, #5
      0083B8 90 AE 00 14      [ 2]  356 ldw	y, #0x0014
      0083BC FF               [ 2]  357 ldw	(x), y
      0083BD 96               [ 1]  358 ldw	x, sp
      0083BE 1C 00 07         [ 2]  359 addw	x, #7
      0083C1 90 AE 00 54      [ 2]  360 ldw	y, #0x0054
      0083C5 FF               [ 2]  361 ldw	(x), y
      0083C6 7B 0E            [ 1]  362 ld	a, (0x0e, sp)
      0083C8 C1 00 03         [ 1]  363 cp	a, __lcd_i2c_rows+0
      0083CB 22 03            [ 1]  364 jrugt	00110$
      0083CD CC 83 D6         [ 2]  365 jp	00102$
      0083D0                        366 00110$:
      0083D0 C6 00 03         [ 1]  367 ld	a, __lcd_i2c_rows+0
      0083D3 4A               [ 1]  368 dec	a
      0083D4 6B 0E            [ 1]  369 ld	(0x0e, sp), a
      0083D6                        370 00102$:
      0083D6 5F               [ 1]  371 clrw	x
      0083D7 7B 0E            [ 1]  372 ld	a, (0x0e, sp)
      0083D9 97               [ 1]  373 ld	xl, a
      0083DA 58               [ 2]  374 sllw	x
      0083DB 1F 09            [ 2]  375 ldw	(0x09, sp), x
      0083DD 96               [ 1]  376 ldw	x, sp
      0083DE 1C 00 01         [ 2]  377 addw	x, #1
      0083E1 72 FB 09         [ 2]  378 addw	x, (0x09, sp)
      0083E4 E6 01            [ 1]  379 ld	a, (0x1, x)
      0083E6 97               [ 1]  380 ld	xl, a
      0083E7 7B 0D            [ 1]  381 ld	a, (0x0d, sp)
      0083E9 89               [ 2]  382 pushw	x
      0083EA 1B 02            [ 1]  383 add	a, (2, sp)
      0083EC 85               [ 2]  384 popw	x
      0083ED AA 80            [ 1]  385 or	a, #0x80
      0083EF 88               [ 1]  386 push	a
      0083F0 CD 83 43         [ 4]  387 call	_LCD_I2C_Command
      0083F3 84               [ 1]  388 pop	a
      0083F4                        389 00103$:
      0083F4 5B 0A            [ 2]  390 addw	sp, #10
      0083F6 81               [ 4]  391 ret
      0083F7                        392 _LCD_I2C_Print:
      0083F7 1E 03            [ 2]  393 ldw	x, (0x03, sp)
      0083F9                        394 00101$:
      0083F9 F6               [ 1]  395 ld	a, (x)
      0083FA 4D               [ 1]  396 tnz	a
      0083FB 26 03            [ 1]  397 jrne	00117$
      0083FD CC 84 0D         [ 2]  398 jp	00104$
      008400                        399 00117$:
      008400 89               [ 2]  400 pushw	x
      008401 4B 01            [ 1]  401 push	#0x01
      008403 88               [ 1]  402 push	a
      008404 CD 83 4D         [ 4]  403 call	_LCD_I2C_Send
      008407 85               [ 2]  404 popw	x
      008408 85               [ 2]  405 popw	x
      008409 5C               [ 1]  406 incw	x
      00840A CC 83 F9         [ 2]  407 jp	00101$
      00840D                        408 00104$:
      00840D 81               [ 4]  409 ret
                                    410 .area CODE
                                    411 .area CONST
                                    412 .area INITIALIZER
                                    413 .area CABS (ABS)
