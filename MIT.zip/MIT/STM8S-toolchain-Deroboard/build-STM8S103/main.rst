                                      1 .module main
                                      2 .optsdcc -mstm8
                                      3 .globl _main
                                      4 .globl _obrazovka
                                      5 .globl _setup
                                      6 .globl _sprintf
                                      7 .globl _delay_ms
                                      8 .globl _LCD_I2C_Print
                                      9 .globl _LCD_I2C_SetCursor
                                     10 .globl _LCD_I2C_Clear
                                     11 .globl _LCD_I2C_Init
                                     12 .globl _milis
                                     13 .globl _init_milis
                                     14 .globl _GPIO_ReadInputPin
                                     15 .globl _GPIO_Init
                                     16 .globl _CLK_HSIPrescalerConfig
                                     17 .globl _time
                                     18 .globl _brana2
                                     19 .globl _brana1
                                     20 .globl _rychlost
                                     21 .globl _rozdil
                                     22 .globl _cas2
                                     23 .globl _cas1
                                     24 .globl _text2
                                     25 .globl _text1
                                     26 .globl _SMER
                                     27 .area DATA
      000008                         28 _SMER::
      000008                         29 .ds 1
      000009                         30 _text1::
      000009                         31 .ds 48
      000039                         32 _text2::
      000039                         33 .ds 48
      000069                         34 _cas1::
      000069                         35 .ds 2
      00006B                         36 _cas2::
      00006B                         37 .ds 2
      00006D                         38 _rozdil::
      00006D                         39 .ds 4
      000071                         40 _rychlost::
      000071                         41 .ds 2
      000073                         42 _brana1::
      000073                         43 .ds 2
      000075                         44 _brana2::
      000075                         45 .ds 2
                                     46 .area INITIALIZED
      000077                         47 _time::
      000077                         48 .ds 4
                                     49 .area	SSEG
      FFFFFF                         50 __start__stack:
      FFFFFF                         51 .ds	1
                                     52 .area DABS (ABS)
                                     53 .area HOME
                                     54 .area GSINIT
                                     55 .area GSFINAL
                                     56 .area CONST
                                     57 .area INITIALIZER
                                     58 .area CODE
                                     59 .area HOME
      008000                         60 __interrupt_vect:
      008000 82 00 80 6F             61 int s_GSINIT ; reset
      008004 82 00 86 DE             62 int _TRAP_IRQHandler ; trap
      008008 82 00 86 DF             63 int _TLI_IRQHandler ; int0
      00800C 82 00 86 E0             64 int _AWU_IRQHandler ; int1
      008010 82 00 86 E1             65 int _CLK_IRQHandler ; int2
      008014 82 00 86 E2             66 int _EXTI_PORTA_IRQHandler ; int3
      008018 82 00 86 E3             67 int _EXTI_PORTB_IRQHandler ; int4
      00801C 82 00 86 E4             68 int _EXTI_PORTC_IRQHandler ; int5
      008020 82 00 86 E5             69 int _EXTI_PORTD_IRQHandler ; int6
      008024 82 00 86 E6             70 int _EXTI_PORTE_IRQHandler ; int7
      008028 82 00 00 00             71 int 0x000000 ; int8
      00802C 82 00 00 00             72 int 0x000000 ; int9
      008030 82 00 86 E7             73 int _SPI_IRQHandler ; int10
      008034 82 00 86 E8             74 int _TIM1_UPD_OVF_TRG_BRK_IRQHandler ; int11
      008038 82 00 86 E9             75 int _TIM1_CAP_COM_IRQHandler ; int12
      00803C 82 00 86 EA             76 int _TIM2_UPD_OVF_BRK_IRQHandler ; int13
      008040 82 00 86 EB             77 int _TIM2_CAP_COM_IRQHandler ; int14
      008044 82 00 00 00             78 int 0x000000 ; int15
      008048 82 00 00 00             79 int 0x000000 ; int16
      00804C 82 00 86 EC             80 int _UART1_TX_IRQHandler ; int17
      008050 82 00 86 ED             81 int _UART1_RX_IRQHandler ; int18
      008054 82 00 86 EE             82 int _I2C_IRQHandler ; int19
      008058 82 00 00 00             83 int 0x000000 ; int20
      00805C 82 00 00 00             84 int 0x000000 ; int21
      008060 82 00 86 EF             85 int _ADC1_IRQHandler ; int22
      008064 82 00 86 C3             86 int _TIM4_UPD_OVF_IRQHandler ; int23
      008068 82 00 86 F0             87 int _EEPROM_EEC_IRQHandler ; int24
                                     88 .area HOME
                                     89 .area GSINIT
                                     90 .area GSFINAL
                                     91 .area GSINIT
      00806F                         92 __sdcc_gs_init_startup:
      00806F                         93 __sdcc_init_data:
      00806F AE 00 76         [ 2]   94 ldw x, #l_DATA
      008072 27 07            [ 1]   95 jreq	00002$
      008074                         96 00001$:
      008074 72 4F 00 00      [ 1]   97 clr (s_DATA - 1, x)
      008078 5A               [ 2]   98 decw x
      008079 26 F9            [ 1]   99 jrne	00001$
      00807B                        100 00002$:
      00807B AE 00 08         [ 2]  101 ldw	x, #l_INITIALIZER
      00807E 27 09            [ 1]  102 jreq	00004$
      008080                        103 00003$:
      008080 D6 80 D7         [ 1]  104 ld	a, (s_INITIALIZER - 1, x)
      008083 D7 00 76         [ 1]  105 ld	(s_INITIALIZED - 1, x), a
      008086 5A               [ 2]  106 decw	x
      008087 26 F7            [ 1]  107 jrne	00003$
      008089                        108 00004$:
                                    109 .area GSFINAL
      008089 CC 80 6C         [ 2]  110 jp	__sdcc_program_startup
                                    111 .area HOME
                                    112 .area HOME
      00806C                        113 __sdcc_program_startup:
      00806C CC 85 31         [ 2]  114 jp	_main
                                    115 .area CODE
      00840E                        116 _setup:
      00840E 4B 00            [ 1]  117 push	#0x00
      008410 CD 87 86         [ 4]  118 call	_CLK_HSIPrescalerConfig
      008413 84               [ 1]  119 pop	a
      008414 4B C0            [ 1]  120 push	#0xc0
      008416 4B 10            [ 1]  121 push	#0x10
      008418 4B 0F            [ 1]  122 push	#0x0f
      00841A 4B 50            [ 1]  123 push	#0x50
      00841C CD 86 F1         [ 4]  124 call	_GPIO_Init
      00841F 5B 04            [ 2]  125 addw	sp, #4
      008421 4B 00            [ 1]  126 push	#0x00
      008423 4B 20            [ 1]  127 push	#0x20
      008425 4B 0A            [ 1]  128 push	#0x0a
      008427 4B 50            [ 1]  129 push	#0x50
      008429 CD 86 F1         [ 4]  130 call	_GPIO_Init
      00842C 5B 04            [ 2]  131 addw	sp, #4
      00842E 4B 00            [ 1]  132 push	#0x00
      008430 4B 40            [ 1]  133 push	#0x40
      008432 4B 0A            [ 1]  134 push	#0x0a
      008434 4B 50            [ 1]  135 push	#0x50
      008436 CD 86 F1         [ 4]  136 call	_GPIO_Init
      008439 5B 04            [ 2]  137 addw	sp, #4
      00843B 4B 02            [ 1]  138 push	#0x02
      00843D 4B 10            [ 1]  139 push	#0x10
      00843F 4B 27            [ 1]  140 push	#0x27
      008441 CD 81 BD         [ 4]  141 call	_LCD_I2C_Init
      008444 5B 03            [ 2]  142 addw	sp, #3
      008446 4B 00            [ 1]  143 push	#0x00
      008448 4B 00            [ 1]  144 push	#0x00
      00844A CD 83 A6         [ 4]  145 call	_LCD_I2C_SetCursor
      00844D 85               [ 2]  146 popw	x
      00844E CC 86 9D         [ 2]  147 jp	_init_milis
      008451                        148 00101$:
      008451 81               [ 4]  149 ret
      008452                        150 _obrazovka:
      008452 89               [ 2]  151 pushw	x
      008453 CD 83 82         [ 4]  152 call	_LCD_I2C_Clear
      008456 7B 05            [ 1]  153 ld	a, (0x05, sp)
      008458 4A               [ 1]  154 dec	a
      008459 26 03            [ 1]  155 jrne	00120$
      00845B CC 84 61         [ 2]  156 jp	00121$
      00845E                        157 00120$:
      00845E CC 84 B2         [ 2]  158 jp	00105$
      008461                        159 00121$:
      008461 4B 00            [ 1]  160 push	#0x00
      008463 4B 00            [ 1]  161 push	#0x00
      008465 CD 83 A6         [ 4]  162 call	_LCD_I2C_SetCursor
      008468 85               [ 2]  163 popw	x
      008469 4B 8C            [ 1]  164 push	#<(___str_0 + 0)
      00846B 4B 80            [ 1]  165 push	#((___str_0 + 0) >> 8)
      00846D CD 83 F7         [ 4]  166 call	_LCD_I2C_Print
      008470 85               [ 2]  167 popw	x
      008471 4B 01            [ 1]  168 push	#0x01
      008473 4B 00            [ 1]  169 push	#0x00
      008475 CD 83 A6         [ 4]  170 call	_LCD_I2C_SetCursor
      008478 85               [ 2]  171 popw	x
      008479 4B E8            [ 1]  172 push	#0xe8
      00847B 4B 03            [ 1]  173 push	#0x03
      00847D CE 00 71         [ 2]  174 ldw	x, _rychlost+0
      008480 89               [ 2]  175 pushw	x
      008481 CD 8F 1F         [ 4]  176 call	__modsint
      008484 5B 04            [ 2]  177 addw	sp, #4
      008486 1F 01            [ 2]  178 ldw	(0x01, sp), x
      008488 4B E8            [ 1]  179 push	#0xe8
      00848A 4B 03            [ 1]  180 push	#0x03
      00848C CE 00 71         [ 2]  181 ldw	x, _rychlost+0
      00848F 89               [ 2]  182 pushw	x
      008490 CD 8F B1         [ 4]  183 call	__divsint
      008493 5B 04            [ 2]  184 addw	sp, #4
      008495 16 01            [ 2]  185 ldw	y, (0x01, sp)
      008497 90 89            [ 2]  186 pushw	y
      008499 89               [ 2]  187 pushw	x
      00849A 4B 9A            [ 1]  188 push	#<(___str_1 + 0)
      00849C 4B 80            [ 1]  189 push	#((___str_1 + 0) >> 8)
      00849E 4B 39            [ 1]  190 push	#<(_text2 + 0)
      0084A0 4B 00            [ 1]  191 push	#((_text2 + 0) >> 8)
      0084A2 CD 8B FC         [ 4]  192 call	_sprintf
      0084A5 5B 08            [ 2]  193 addw	sp, #8
      0084A7 4B 39            [ 1]  194 push	#<(_text2 + 0)
      0084A9 4B 00            [ 1]  195 push	#((_text2 + 0) >> 8)
      0084AB CD 83 F7         [ 4]  196 call	_LCD_I2C_Print
      0084AE 85               [ 2]  197 popw	x
      0084AF CC 85 2F         [ 2]  198 jp	00107$
      0084B2                        199 00105$:
      0084B2 7B 05            [ 1]  200 ld	a, (0x05, sp)
      0084B4 A1 02            [ 1]  201 cp	a, #0x02
      0084B6 26 03            [ 1]  202 jrne	00123$
      0084B8 CC 84 BE         [ 2]  203 jp	00124$
      0084BB                        204 00123$:
      0084BB CC 85 0F         [ 2]  205 jp	00102$
      0084BE                        206 00124$:
      0084BE 4B 00            [ 1]  207 push	#0x00
      0084C0 4B 00            [ 1]  208 push	#0x00
      0084C2 CD 83 A6         [ 4]  209 call	_LCD_I2C_SetCursor
      0084C5 85               [ 2]  210 popw	x
      0084C6 4B AD            [ 1]  211 push	#<(___str_2 + 0)
      0084C8 4B 80            [ 1]  212 push	#((___str_2 + 0) >> 8)
      0084CA CD 83 F7         [ 4]  213 call	_LCD_I2C_Print
      0084CD 85               [ 2]  214 popw	x
      0084CE 4B 01            [ 1]  215 push	#0x01
      0084D0 4B 00            [ 1]  216 push	#0x00
      0084D2 CD 83 A6         [ 4]  217 call	_LCD_I2C_SetCursor
      0084D5 85               [ 2]  218 popw	x
      0084D6 4B E8            [ 1]  219 push	#0xe8
      0084D8 4B 03            [ 1]  220 push	#0x03
      0084DA CE 00 71         [ 2]  221 ldw	x, _rychlost+0
      0084DD 89               [ 2]  222 pushw	x
      0084DE CD 8F 1F         [ 4]  223 call	__modsint
      0084E1 5B 04            [ 2]  224 addw	sp, #4
      0084E3 1F 01            [ 2]  225 ldw	(0x01, sp), x
      0084E5 4B E8            [ 1]  226 push	#0xe8
      0084E7 4B 03            [ 1]  227 push	#0x03
      0084E9 CE 00 71         [ 2]  228 ldw	x, _rychlost+0
      0084EC 89               [ 2]  229 pushw	x
      0084ED CD 8F B1         [ 4]  230 call	__divsint
      0084F0 5B 04            [ 2]  231 addw	sp, #4
      0084F2 16 01            [ 2]  232 ldw	y, (0x01, sp)
      0084F4 90 89            [ 2]  233 pushw	y
      0084F6 89               [ 2]  234 pushw	x
      0084F7 4B 9A            [ 1]  235 push	#<(___str_1 + 0)
      0084F9 4B 80            [ 1]  236 push	#((___str_1 + 0) >> 8)
      0084FB 4B 39            [ 1]  237 push	#<(_text2 + 0)
      0084FD 4B 00            [ 1]  238 push	#((_text2 + 0) >> 8)
      0084FF CD 8B FC         [ 4]  239 call	_sprintf
      008502 5B 08            [ 2]  240 addw	sp, #8
      008504 4B 39            [ 1]  241 push	#<(_text2 + 0)
      008506 4B 00            [ 1]  242 push	#((_text2 + 0) >> 8)
      008508 CD 83 F7         [ 4]  243 call	_LCD_I2C_Print
      00850B 85               [ 2]  244 popw	x
      00850C CC 85 2F         [ 2]  245 jp	00107$
      00850F                        246 00102$:
      00850F 4B 00            [ 1]  247 push	#0x00
      008511 4B 00            [ 1]  248 push	#0x00
      008513 CD 83 A6         [ 4]  249 call	_LCD_I2C_SetCursor
      008516 85               [ 2]  250 popw	x
      008517 4B B7            [ 1]  251 push	#<(___str_3 + 0)
      008519 4B 80            [ 1]  252 push	#((___str_3 + 0) >> 8)
      00851B CD 83 F7         [ 4]  253 call	_LCD_I2C_Print
      00851E 85               [ 2]  254 popw	x
      00851F 4B 01            [ 1]  255 push	#0x01
      008521 4B 00            [ 1]  256 push	#0x00
      008523 CD 83 A6         [ 4]  257 call	_LCD_I2C_SetCursor
      008526 85               [ 2]  258 popw	x
      008527 4B BE            [ 1]  259 push	#<(___str_4 + 0)
      008529 4B 80            [ 1]  260 push	#((___str_4 + 0) >> 8)
      00852B CD 83 F7         [ 4]  261 call	_LCD_I2C_Print
      00852E 85               [ 2]  262 popw	x
      00852F                        263 00107$:
      00852F 85               [ 2]  264 popw	x
      008530 81               [ 4]  265 ret
      008531                        266 _main:
      008531 52 04            [ 2]  267 sub	sp, #4
      008533 CD 84 0E         [ 4]  268 call	_setup
      008536 4B 00            [ 1]  269 push	#0x00
      008538 CD 84 52         [ 4]  270 call	_obrazovka
      00853B 84               [ 1]  271 pop	a
      00853C                        272 00116$:
      00853C 4B 20            [ 1]  273 push	#0x20
      00853E 4B 0A            [ 1]  274 push	#0x0a
      008540 4B 50            [ 1]  275 push	#0x50
      008542 CD 87 7F         [ 4]  276 call	_GPIO_ReadInputPin
      008545 5B 03            [ 2]  277 addw	sp, #3
      008547 4D               [ 1]  278 tnz	a
      008548 26 03            [ 1]  279 jrne	00165$
      00854A CC 85 5C         [ 2]  280 jp	00104$
      00854D                        281 00165$:
      00854D CD 86 7B         [ 4]  282 call	_milis
      008550 CF 00 69         [ 2]  283 ldw	_cas1+0, x
      008553 AE 00 01         [ 2]  284 ldw	x, #0x0001
      008556 CF 00 73         [ 2]  285 ldw	_brana1+0, x
      008559 CC 85 7D         [ 2]  286 jp	00105$
      00855C                        287 00104$:
      00855C 4B 40            [ 1]  288 push	#0x40
      00855E 4B 0A            [ 1]  289 push	#0x0a
      008560 4B 50            [ 1]  290 push	#0x50
      008562 CD 87 7F         [ 4]  291 call	_GPIO_ReadInputPin
      008565 5B 03            [ 2]  292 addw	sp, #3
      008567 4D               [ 1]  293 tnz	a
      008568 26 03            [ 1]  294 jrne	00166$
      00856A CC 85 7D         [ 2]  295 jp	00105$
      00856D                        296 00166$:
      00856D CD 86 7B         [ 4]  297 call	_milis
      008570 1F 03            [ 2]  298 ldw	(0x03, sp), x
      008572 1E 03            [ 2]  299 ldw	x, (0x03, sp)
      008574 CF 00 6B         [ 2]  300 ldw	_cas2+0, x
      008577 AE 00 01         [ 2]  301 ldw	x, #0x0001
      00857A CF 00 75         [ 2]  302 ldw	_brana2+0, x
      00857D                        303 00105$:
      00857D CE 00 73         [ 2]  304 ldw	x, _brana1+0
      008580 5A               [ 2]  305 decw	x
      008581 26 07            [ 1]  306 jrne	00168$
      008583 A6 01            [ 1]  307 ld	a, #0x01
      008585 6B 04            [ 1]  308 ld	(0x04, sp), a
      008587 CC 85 8C         [ 2]  309 jp	00169$
      00858A                        310 00168$:
      00858A 0F 04            [ 1]  311 clr	(0x04, sp)
      00858C                        312 00169$:
      00858C CE 00 75         [ 2]  313 ldw	x, _brana2+0
      00858F 5A               [ 2]  314 decw	x
      008590 26 05            [ 1]  315 jrne	00171$
      008592 A6 01            [ 1]  316 ld	a, #0x01
      008594 CC 85 98         [ 2]  317 jp	00172$
      008597                        318 00171$:
      008597 4F               [ 1]  319 clr	a
      008598                        320 00172$:
      008598 CE 00 6B         [ 2]  321 ldw	x, _cas2+0
      00859B C3 00 69         [ 2]  322 cpw	x, _cas1+0
      00859E 2C 03            [ 1]  323 jrsgt	00173$
      0085A0 CC 86 08         [ 2]  324 jp	00111$
      0085A3                        325 00173$:
      0085A3 0D 04            [ 1]  326 tnz	(0x04, sp)
      0085A5 26 03            [ 1]  327 jrne	00174$
      0085A7 CC 86 08         [ 2]  328 jp	00111$
      0085AA                        329 00174$:
      0085AA 4D               [ 1]  330 tnz	a
      0085AB 26 03            [ 1]  331 jrne	00175$
      0085AD CC 86 08         [ 2]  332 jp	00111$
      0085B0                        333 00175$:
      0085B0 CE 00 6B         [ 2]  334 ldw	x, _cas2+0
      0085B3 72 B0 00 69      [ 2]  335 subw	x, _cas1+0
      0085B7 89               [ 2]  336 pushw	x
      0085B8 CD 8C 17         [ 4]  337 call	___sint2fs
      0085BB 5B 02            [ 2]  338 addw	sp, #2
      0085BD CF 00 6F         [ 2]  339 ldw	_rozdil+2, x
      0085C0 90 CF 00 6D      [ 2]  340 ldw	_rozdil+0, y
      0085C4 CE 00 6F         [ 2]  341 ldw	x, _rozdil+2
      0085C7 89               [ 2]  342 pushw	x
      0085C8 CE 00 6D         [ 2]  343 ldw	x, _rozdil+0
      0085CB 89               [ 2]  344 pushw	x
      0085CC 4B 00            [ 1]  345 push	#0x00
      0085CE 4B 50            [ 1]  346 push	#0x50
      0085D0 4B 43            [ 1]  347 push	#0x43
      0085D2 4B 48            [ 1]  348 push	#0x48
      0085D4 CD 8E 8E         [ 4]  349 call	___fsdiv
      0085D7 5B 08            [ 2]  350 addw	sp, #8
      0085D9 89               [ 2]  351 pushw	x
      0085DA 90 89            [ 2]  352 pushw	y
      0085DC CD 8C 28         [ 4]  353 call	___fs2sint
      0085DF 5B 04            [ 2]  354 addw	sp, #4
      0085E1 CF 00 71         [ 2]  355 ldw	_rychlost+0, x
      0085E4 5F               [ 1]  356 clrw	x
      0085E5 CF 00 73         [ 2]  357 ldw	_brana1+0, x
      0085E8 5F               [ 1]  358 clrw	x
      0085E9 CF 00 75         [ 2]  359 ldw	_brana2+0, x
      0085EC 5F               [ 1]  360 clrw	x
      0085ED CF 00 69         [ 2]  361 ldw	_cas1+0, x
      0085F0 5F               [ 1]  362 clrw	x
      0085F1 CF 00 6B         [ 2]  363 ldw	_cas2+0, x
      0085F4 4B 02            [ 1]  364 push	#0x02
      0085F6 CD 84 52         [ 4]  365 call	_obrazovka
      0085F9 84               [ 1]  366 pop	a
      0085FA 4B F4            [ 1]  367 push	#0xf4
      0085FC 4B 01            [ 1]  368 push	#0x01
      0085FE 5F               [ 1]  369 clrw	x
      0085FF 89               [ 2]  370 pushw	x
      008600 CD 80 E0         [ 4]  371 call	_delay_ms
      008603 5B 04            [ 2]  372 addw	sp, #4
      008605 CC 85 3C         [ 2]  373 jp	00116$
      008608                        374 00111$:
      008608 CE 00 6B         [ 2]  375 ldw	x, _cas2+0
      00860B C3 00 69         [ 2]  376 cpw	x, _cas1+0
      00860E 2F 03            [ 1]  377 jrslt	00176$
      008610 CC 85 3C         [ 2]  378 jp	00116$
      008613                        379 00176$:
      008613 0D 04            [ 1]  380 tnz	(0x04, sp)
      008615 26 03            [ 1]  381 jrne	00177$
      008617 CC 85 3C         [ 2]  382 jp	00116$
      00861A                        383 00177$:
      00861A 4D               [ 1]  384 tnz	a
      00861B 26 03            [ 1]  385 jrne	00178$
      00861D CC 85 3C         [ 2]  386 jp	00116$
      008620                        387 00178$:
      008620 CE 00 69         [ 2]  388 ldw	x, _cas1+0
      008623 72 B0 00 6B      [ 2]  389 subw	x, _cas2+0
      008627 89               [ 2]  390 pushw	x
      008628 CD 8C 17         [ 4]  391 call	___sint2fs
      00862B 5B 02            [ 2]  392 addw	sp, #2
      00862D CF 00 6F         [ 2]  393 ldw	_rozdil+2, x
      008630 90 CF 00 6D      [ 2]  394 ldw	_rozdil+0, y
      008634 CE 00 6F         [ 2]  395 ldw	x, _rozdil+2
      008637 89               [ 2]  396 pushw	x
      008638 CE 00 6D         [ 2]  397 ldw	x, _rozdil+0
      00863B 89               [ 2]  398 pushw	x
      00863C 4B 00            [ 1]  399 push	#0x00
      00863E 4B 50            [ 1]  400 push	#0x50
      008640 4B 43            [ 1]  401 push	#0x43
      008642 4B 48            [ 1]  402 push	#0x48
      008644 CD 8E 8E         [ 4]  403 call	___fsdiv
      008647 5B 08            [ 2]  404 addw	sp, #8
      008649 89               [ 2]  405 pushw	x
      00864A 90 89            [ 2]  406 pushw	y
      00864C CD 8C 28         [ 4]  407 call	___fs2sint
      00864F 5B 04            [ 2]  408 addw	sp, #4
      008651 CF 00 71         [ 2]  409 ldw	_rychlost+0, x
      008654 5F               [ 1]  410 clrw	x
      008655 CF 00 73         [ 2]  411 ldw	_brana1+0, x
      008658 5F               [ 1]  412 clrw	x
      008659 CF 00 75         [ 2]  413 ldw	_brana2+0, x
      00865C 5F               [ 1]  414 clrw	x
      00865D CF 00 69         [ 2]  415 ldw	_cas1+0, x
      008660 5F               [ 1]  416 clrw	x
      008661 CF 00 6B         [ 2]  417 ldw	_cas2+0, x
      008664 4B 01            [ 1]  418 push	#0x01
      008666 CD 84 52         [ 4]  419 call	_obrazovka
      008669 84               [ 1]  420 pop	a
      00866A 4B F4            [ 1]  421 push	#0xf4
      00866C 4B 01            [ 1]  422 push	#0x01
      00866E 5F               [ 1]  423 clrw	x
      00866F 89               [ 2]  424 pushw	x
      008670 CD 80 E0         [ 4]  425 call	_delay_ms
      008673 5B 04            [ 2]  426 addw	sp, #4
      008675 CC 85 3C         [ 2]  427 jp	00116$
      008678                        428 00118$:
      008678 5B 04            [ 2]  429 addw	sp, #4
      00867A 81               [ 4]  430 ret
                                    431 .area CODE
                                    432 .area CONST
                                    433 .area CONST
      00808C                        434 ___str_0:
      00808C 53 6D 65 72 3A 20 44   435 .ascii "Smer: Dovnitr"
             6F 76 6E 69 74 72
      008099 00                     436 .db 0x00
                                    437 .area CODE
                                    438 .area CONST
      00809A                        439 ___str_1:
      00809A 52 79 63 68 3A 20 25   440 .ascii "Rych: %2d.%03d m/s"
             32 64 2E 25 30 33 64
             20 6D 2F 73
      0080AC 00                     441 .db 0x00
                                    442 .area CODE
                                    443 .area CONST
      0080AD                        444 ___str_2:
      0080AD 53 6D 65 72 3A 20 56   445 .ascii "Smer: Ven"
             65 6E
      0080B6 00                     446 .db 0x00
                                    447 .area CODE
                                    448 .area CONST
      0080B7                        449 ___str_3:
      0080B7 53 6D 65 72 3A 20      450 .ascii "Smer: "
      0080BD 00                     451 .db 0x00
                                    452 .area CODE
                                    453 .area CONST
      0080BE                        454 ___str_4:
      0080BE 52 79 63 68 6C 6F 73   455 .ascii "Rychlost: "
             74 3A 20
      0080C8 00                     456 .db 0x00
                                    457 .area CODE
                                    458 .area INITIALIZER
      0080D8                        459 __xinit__time:
      0080D8 00 00 00 00            460 .byte #0x00, #0x00, #0x00, #0x00	; 0
                                    461 .area CABS (ABS)
