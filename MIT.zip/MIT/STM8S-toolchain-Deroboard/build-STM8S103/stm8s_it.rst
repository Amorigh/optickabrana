                                      1 .module stm8s_it
                                      2 .optsdcc -mstm8
                                      3 .globl _TRAP_IRQHandler
                                      4 .globl _TLI_IRQHandler
                                      5 .globl _AWU_IRQHandler
                                      6 .globl _CLK_IRQHandler
                                      7 .globl _EXTI_PORTA_IRQHandler
                                      8 .globl _EXTI_PORTB_IRQHandler
                                      9 .globl _EXTI_PORTC_IRQHandler
                                     10 .globl _EXTI_PORTD_IRQHandler
                                     11 .globl _EXTI_PORTE_IRQHandler
                                     12 .globl _SPI_IRQHandler
                                     13 .globl _TIM1_UPD_OVF_TRG_BRK_IRQHandler
                                     14 .globl _TIM1_CAP_COM_IRQHandler
                                     15 .globl _TIM2_UPD_OVF_BRK_IRQHandler
                                     16 .globl _TIM2_CAP_COM_IRQHandler
                                     17 .globl _UART1_TX_IRQHandler
                                     18 .globl _UART1_RX_IRQHandler
                                     19 .globl _I2C_IRQHandler
                                     20 .globl _ADC1_IRQHandler
                                     21 .globl _EEPROM_EEC_IRQHandler
                                     22 .area DATA
                                     23 .area INITIALIZED
                                     24 .area DABS (ABS)
                                     25 .area HOME
                                     26 .area GSINIT
                                     27 .area GSFINAL
                                     28 .area CONST
                                     29 .area INITIALIZER
                                     30 .area CODE
                                     31 .area HOME
                                     32 .area GSINIT
                                     33 .area GSFINAL
                                     34 .area GSINIT
                                     35 .area HOME
                                     36 .area HOME
                                     37 .area CODE
      0086DE                         38 _TRAP_IRQHandler:
      0086DE                         39 00101$:
      0086DE 80               [11]   40 iret
      0086DF                         41 _TLI_IRQHandler:
      0086DF                         42 00101$:
      0086DF 80               [11]   43 iret
      0086E0                         44 _AWU_IRQHandler:
      0086E0                         45 00101$:
      0086E0 80               [11]   46 iret
      0086E1                         47 _CLK_IRQHandler:
      0086E1                         48 00101$:
      0086E1 80               [11]   49 iret
      0086E2                         50 _EXTI_PORTA_IRQHandler:
      0086E2                         51 00101$:
      0086E2 80               [11]   52 iret
      0086E3                         53 _EXTI_PORTB_IRQHandler:
      0086E3                         54 00101$:
      0086E3 80               [11]   55 iret
      0086E4                         56 _EXTI_PORTC_IRQHandler:
      0086E4                         57 00101$:
      0086E4 80               [11]   58 iret
      0086E5                         59 _EXTI_PORTD_IRQHandler:
      0086E5                         60 00101$:
      0086E5 80               [11]   61 iret
      0086E6                         62 _EXTI_PORTE_IRQHandler:
      0086E6                         63 00101$:
      0086E6 80               [11]   64 iret
      0086E7                         65 _SPI_IRQHandler:
      0086E7                         66 00101$:
      0086E7 80               [11]   67 iret
      0086E8                         68 _TIM1_UPD_OVF_TRG_BRK_IRQHandler:
      0086E8                         69 00101$:
      0086E8 80               [11]   70 iret
      0086E9                         71 _TIM1_CAP_COM_IRQHandler:
      0086E9                         72 00101$:
      0086E9 80               [11]   73 iret
      0086EA                         74 _TIM2_UPD_OVF_BRK_IRQHandler:
      0086EA                         75 00101$:
      0086EA 80               [11]   76 iret
      0086EB                         77 _TIM2_CAP_COM_IRQHandler:
      0086EB                         78 00101$:
      0086EB 80               [11]   79 iret
      0086EC                         80 _UART1_TX_IRQHandler:
      0086EC                         81 00101$:
      0086EC 80               [11]   82 iret
      0086ED                         83 _UART1_RX_IRQHandler:
      0086ED                         84 00101$:
      0086ED 80               [11]   85 iret
      0086EE                         86 _I2C_IRQHandler:
      0086EE                         87 00101$:
      0086EE 80               [11]   88 iret
      0086EF                         89 _ADC1_IRQHandler:
      0086EF                         90 00101$:
      0086EF 80               [11]   91 iret
      0086F0                         92 _EEPROM_EEC_IRQHandler:
      0086F0                         93 00101$:
      0086F0 80               [11]   94 iret
                                     95 .area CODE
                                     96 .area CONST
                                     97 .area INITIALIZER
                                     98 .area CABS (ABS)
