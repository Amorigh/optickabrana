                                      1 .module stm8s_gpio
                                      2 .optsdcc -mstm8
                                      3 .globl _GPIO_Init
                                      4 .globl _GPIO_WriteReverse
                                      5 .globl _GPIO_ReadInputPin
                                      6 .area DATA
                                      7 .area INITIALIZED
                                      8 .area DABS (ABS)
                                      9 .area HOME
                                     10 .area GSINIT
                                     11 .area GSFINAL
                                     12 .area CONST
                                     13 .area INITIALIZER
                                     14 .area CODE
                                     15 .area HOME
                                     16 .area GSINIT
                                     17 .area GSFINAL
                                     18 .area GSINIT
                                     19 .area HOME
                                     20 .area HOME
                                     21 .area CODE
      0086F1                         22 _GPIO_Init:
      0086F1 52 05            [ 2]   23 sub	sp, #5
      0086F3 16 08            [ 2]   24 ldw	y, (0x08, sp)
      0086F5 93               [ 1]   25 ldw	x, y
      0086F6 1C 00 04         [ 2]   26 addw	x, #0x0004
      0086F9 1F 01            [ 2]   27 ldw	(0x01, sp), x
      0086FB 1E 01            [ 2]   28 ldw	x, (0x01, sp)
      0086FD F6               [ 1]   29 ld	a, (x)
      0086FE 88               [ 1]   30 push	a
      0086FF 7B 0B            [ 1]   31 ld	a, (0x0b, sp)
      008701 43               [ 1]   32 cpl	a
      008702 6B 04            [ 1]   33 ld	(0x04, sp), a
      008704 84               [ 1]   34 pop	a
      008705 14 03            [ 1]   35 and	a, (0x03, sp)
      008707 1E 01            [ 2]   36 ldw	x, (0x01, sp)
      008709 F7               [ 1]   37 ld	(x), a
      00870A 93               [ 1]   38 ldw	x, y
      00870B 5C               [ 1]   39 incw	x
      00870C 5C               [ 1]   40 incw	x
      00870D 1F 04            [ 2]   41 ldw	(0x04, sp), x
      00870F 0D 0B            [ 1]   42 tnz	(0x0b, sp)
      008711 2B 03            [ 1]   43 jrmi	00135$
      008713 CC 87 39         [ 2]   44 jp	00105$
      008716                         45 00135$:
      008716 90 F6            [ 1]   46 ld	a, (y)
      008718 88               [ 1]   47 push	a
      008719 7B 0C            [ 1]   48 ld	a, (0x0c, sp)
      00871B A5 10            [ 1]   49 bcp	a, #0x10
      00871D 84               [ 1]   50 pop	a
      00871E 26 03            [ 1]   51 jrne	00136$
      008720 CC 87 2A         [ 2]   52 jp	00102$
      008723                         53 00136$:
      008723 1A 0A            [ 1]   54 or	a, (0x0a, sp)
      008725 90 F7            [ 1]   55 ld	(y), a
      008727 CC 87 2E         [ 2]   56 jp	00103$
      00872A                         57 00102$:
      00872A 14 03            [ 1]   58 and	a, (0x03, sp)
      00872C 90 F7            [ 1]   59 ld	(y), a
      00872E                         60 00103$:
      00872E 1E 04            [ 2]   61 ldw	x, (0x04, sp)
      008730 F6               [ 1]   62 ld	a, (x)
      008731 1A 0A            [ 1]   63 or	a, (0x0a, sp)
      008733 1E 04            [ 2]   64 ldw	x, (0x04, sp)
      008735 F7               [ 1]   65 ld	(x), a
      008736 CC 87 41         [ 2]   66 jp	00106$
      008739                         67 00105$:
      008739 1E 04            [ 2]   68 ldw	x, (0x04, sp)
      00873B F6               [ 1]   69 ld	a, (x)
      00873C 14 03            [ 1]   70 and	a, (0x03, sp)
      00873E 1E 04            [ 2]   71 ldw	x, (0x04, sp)
      008740 F7               [ 1]   72 ld	(x), a
      008741                         73 00106$:
      008741 93               [ 1]   74 ldw	x, y
      008742 1C 00 03         [ 2]   75 addw	x, #0x0003
      008745 F6               [ 1]   76 ld	a, (x)
      008746 88               [ 1]   77 push	a
      008747 7B 0C            [ 1]   78 ld	a, (0x0c, sp)
      008749 A5 40            [ 1]   79 bcp	a, #0x40
      00874B 84               [ 1]   80 pop	a
      00874C 26 03            [ 1]   81 jrne	00137$
      00874E CC 87 57         [ 2]   82 jp	00108$
      008751                         83 00137$:
      008751 1A 0A            [ 1]   84 or	a, (0x0a, sp)
      008753 F7               [ 1]   85 ld	(x), a
      008754 CC 87 5A         [ 2]   86 jp	00109$
      008757                         87 00108$:
      008757 14 03            [ 1]   88 and	a, (0x03, sp)
      008759 F7               [ 1]   89 ld	(x), a
      00875A                         90 00109$:
      00875A 1E 01            [ 2]   91 ldw	x, (0x01, sp)
      00875C F6               [ 1]   92 ld	a, (x)
      00875D 88               [ 1]   93 push	a
      00875E 7B 0C            [ 1]   94 ld	a, (0x0c, sp)
      008760 A5 20            [ 1]   95 bcp	a, #0x20
      008762 84               [ 1]   96 pop	a
      008763 26 03            [ 1]   97 jrne	00138$
      008765 CC 87 70         [ 2]   98 jp	00111$
      008768                         99 00138$:
      008768 1A 0A            [ 1]  100 or	a, (0x0a, sp)
      00876A 1E 01            [ 2]  101 ldw	x, (0x01, sp)
      00876C F7               [ 1]  102 ld	(x), a
      00876D CC 87 75         [ 2]  103 jp	00113$
      008770                        104 00111$:
      008770 14 03            [ 1]  105 and	a, (0x03, sp)
      008772 1E 01            [ 2]  106 ldw	x, (0x01, sp)
      008774 F7               [ 1]  107 ld	(x), a
      008775                        108 00113$:
      008775 5B 05            [ 2]  109 addw	sp, #5
      008777 81               [ 4]  110 ret
      008778                        111 _GPIO_WriteReverse:
      008778 1E 03            [ 2]  112 ldw	x, (0x03, sp)
      00877A F6               [ 1]  113 ld	a, (x)
      00877B 18 05            [ 1]  114 xor	a, (0x05, sp)
      00877D F7               [ 1]  115 ld	(x), a
      00877E                        116 00101$:
      00877E 81               [ 4]  117 ret
      00877F                        118 _GPIO_ReadInputPin:
      00877F 1E 03            [ 2]  119 ldw	x, (0x03, sp)
      008781 E6 01            [ 1]  120 ld	a, (0x1, x)
      008783 14 05            [ 1]  121 and	a, (0x05, sp)
      008785                        122 00101$:
      008785 81               [ 4]  123 ret
                                    124 .area CODE
                                    125 .area CONST
                                    126 .area INITIALIZER
                                    127 .area CABS (ABS)
