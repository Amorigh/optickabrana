                                      1 .module stm8s_i2c
                                      2 .optsdcc -mstm8
                                      3 .globl _I2C_DeInit
                                      4 .globl _I2C_Init
                                      5 .globl _I2C_Cmd
                                      6 .globl _I2C_GenerateSTART
                                      7 .globl _I2C_GenerateSTOP
                                      8 .globl _I2C_AcknowledgeConfig
                                      9 .globl _I2C_Send7bitAddress
                                     10 .globl _I2C_SendData
                                     11 .globl _I2C_CheckEvent
                                     12 .globl _I2C_GetFlagStatus
                                     13 .area DATA
                                     14 .area INITIALIZED
                                     15 .area DABS (ABS)
                                     16 .area HOME
                                     17 .area GSINIT
                                     18 .area GSFINAL
                                     19 .area CONST
                                     20 .area INITIALIZER
                                     21 .area CODE
                                     22 .area HOME
                                     23 .area GSINIT
                                     24 .area GSFINAL
                                     25 .area GSINIT
                                     26 .area HOME
                                     27 .area HOME
                                     28 .area CODE
      008946                         29 _I2C_DeInit:
      008946 35 00 52 10      [ 1]   30 mov	0x5210+0, #0x00
      00894A 35 00 52 11      [ 1]   31 mov	0x5211+0, #0x00
      00894E 35 00 52 12      [ 1]   32 mov	0x5212+0, #0x00
      008952 35 00 52 13      [ 1]   33 mov	0x5213+0, #0x00
      008956 35 00 52 14      [ 1]   34 mov	0x5214+0, #0x00
      00895A 35 00 52 1A      [ 1]   35 mov	0x521a+0, #0x00
      00895E 35 00 52 1B      [ 1]   36 mov	0x521b+0, #0x00
      008962 35 00 52 1C      [ 1]   37 mov	0x521c+0, #0x00
      008966 35 02 52 1D      [ 1]   38 mov	0x521d+0, #0x02
      00896A                         39 00101$:
      00896A 81               [ 4]   40 ret
      00896B                         41 _I2C_Init:
      00896B 52 05            [ 2]   42 sub	sp, #5
      00896D 0F 05            [ 1]   43 clr	(0x05, sp)
      00896F C6 52 12         [ 1]   44 ld	a, 0x5212
      008972 A4 C0            [ 1]   45 and	a, #0xc0
      008974 C7 52 12         [ 1]   46 ld	0x5212, a
      008977 C6 52 12         [ 1]   47 ld	a, 0x5212
      00897A 1A 11            [ 1]   48 or	a, (0x11, sp)
      00897C C7 52 12         [ 1]   49 ld	0x5212, a
      00897F C6 52 10         [ 1]   50 ld	a, 0x5210
      008982 A4 FE            [ 1]   51 and	a, #0xfe
      008984 C7 52 10         [ 1]   52 ld	0x5210, a
      008987 C6 52 1C         [ 1]   53 ld	a, 0x521c
      00898A A4 30            [ 1]   54 and	a, #0x30
      00898C C7 52 1C         [ 1]   55 ld	0x521c, a
      00898F C6 52 1B         [ 1]   56 ld	a, 0x521b
      008992 35 00 52 1B      [ 1]   57 mov	0x521b+0, #0x00
      008996 5F               [ 1]   58 clrw	x
      008997 7B 11            [ 1]   59 ld	a, (0x11, sp)
      008999 97               [ 1]   60 ld	xl, a
      00899A 90 5F            [ 1]   61 clrw	y
      00899C 89               [ 2]   62 pushw	x
      00899D 90 89            [ 2]   63 pushw	y
      00899F 4B 40            [ 1]   64 push	#0x40
      0089A1 4B 42            [ 1]   65 push	#0x42
      0089A3 4B 0F            [ 1]   66 push	#0x0f
      0089A5 4B 00            [ 1]   67 push	#0x00
      0089A7 CD 8F 35         [ 4]   68 call	__mullong
      0089AA 5B 08            [ 2]   69 addw	sp, #8
      0089AC 1F 03            [ 2]   70 ldw	(0x03, sp), x
      0089AE 17 01            [ 2]   71 ldw	(0x01, sp), y
      0089B0 AE 86 A0         [ 2]   72 ldw	x, #0x86a0
      0089B3 13 0A            [ 2]   73 cpw	x, (0x0a, sp)
      0089B5 A6 01            [ 1]   74 ld	a, #0x01
      0089B7 12 09            [ 1]   75 sbc	a, (0x09, sp)
      0089B9 4F               [ 1]   76 clr	a
      0089BA 12 08            [ 1]   77 sbc	a, (0x08, sp)
      0089BC 25 03            [ 1]   78 jrc	00133$
      0089BE CC 8A 47         [ 2]   79 jp	00109$
      0089C1                         80 00133$:
      0089C1 A6 80            [ 1]   81 ld	a, #0x80
      0089C3 6B 05            [ 1]   82 ld	(0x05, sp), a
      0089C5 0D 0E            [ 1]   83 tnz	(0x0e, sp)
      0089C7 27 03            [ 1]   84 jreq	00134$
      0089C9 CC 89 EE         [ 2]   85 jp	00102$
      0089CC                         86 00134$:
      0089CC 1E 0A            [ 2]   87 ldw	x, (0x0a, sp)
      0089CE 89               [ 2]   88 pushw	x
      0089CF 1E 0A            [ 2]   89 ldw	x, (0x0a, sp)
      0089D1 89               [ 2]   90 pushw	x
      0089D2 4B 03            [ 1]   91 push	#0x03
      0089D4 5F               [ 1]   92 clrw	x
      0089D5 89               [ 2]   93 pushw	x
      0089D6 4B 00            [ 1]   94 push	#0x00
      0089D8 CD 8F 35         [ 4]   95 call	__mullong
      0089DB 5B 08            [ 2]   96 addw	sp, #8
      0089DD 89               [ 2]   97 pushw	x
      0089DE 90 89            [ 2]   98 pushw	y
      0089E0 1E 07            [ 2]   99 ldw	x, (0x07, sp)
      0089E2 89               [ 2]  100 pushw	x
      0089E3 1E 07            [ 2]  101 ldw	x, (0x07, sp)
      0089E5 89               [ 2]  102 pushw	x
      0089E6 CD 8C 67         [ 4]  103 call	__divulong
      0089E9 5B 08            [ 2]  104 addw	sp, #8
      0089EB CC 8A 16         [ 2]  105 jp	00103$
      0089EE                        106 00102$:
      0089EE 1E 0A            [ 2]  107 ldw	x, (0x0a, sp)
      0089F0 89               [ 2]  108 pushw	x
      0089F1 1E 0A            [ 2]  109 ldw	x, (0x0a, sp)
      0089F3 89               [ 2]  110 pushw	x
      0089F4 4B 19            [ 1]  111 push	#0x19
      0089F6 5F               [ 1]  112 clrw	x
      0089F7 89               [ 2]  113 pushw	x
      0089F8 4B 00            [ 1]  114 push	#0x00
      0089FA CD 8F 35         [ 4]  115 call	__mullong
      0089FD 5B 08            [ 2]  116 addw	sp, #8
      0089FF 9F               [ 1]  117 ld	a, xl
      008A00 88               [ 1]  118 push	a
      008A01 9E               [ 1]  119 ld	a, xh
      008A02 88               [ 1]  120 push	a
      008A03 90 89            [ 2]  121 pushw	y
      008A05 1E 07            [ 2]  122 ldw	x, (0x07, sp)
      008A07 89               [ 2]  123 pushw	x
      008A08 1E 07            [ 2]  124 ldw	x, (0x07, sp)
      008A0A 89               [ 2]  125 pushw	x
      008A0B CD 8C 67         [ 4]  126 call	__divulong
      008A0E 5B 08            [ 2]  127 addw	sp, #8
      008A10 7B 05            [ 1]  128 ld	a, (0x05, sp)
      008A12 AA 40            [ 1]  129 or	a, #0x40
      008A14 6B 05            [ 1]  130 ld	(0x05, sp), a
      008A16                        131 00103$:
      008A16 A3 00 01         [ 2]  132 cpw	x, #0x0001
      008A19 25 03            [ 1]  133 jrc	00135$
      008A1B CC 8A 20         [ 2]  134 jp	00105$
      008A1E                        135 00135$:
      008A1E 5F               [ 1]  136 clrw	x
      008A1F 5C               [ 1]  137 incw	x
      008A20                        138 00105$:
      008A20 7B 11            [ 1]  139 ld	a, (0x11, sp)
      008A22 6B 04            [ 1]  140 ld	(0x04, sp), a
      008A24 0F 03            [ 1]  141 clr	(0x03, sp)
      008A26 89               [ 2]  142 pushw	x
      008A27 1E 05            [ 2]  143 ldw	x, (0x05, sp)
      008A29 58               [ 2]  144 sllw	x
      008A2A 72 FB 05         [ 2]  145 addw	x, (0x05, sp)
      008A2D 51               [ 1]  146 exgw	x, y
      008A2E 85               [ 2]  147 popw	x
      008A2F 89               [ 2]  148 pushw	x
      008A30 4B 0A            [ 1]  149 push	#0x0a
      008A32 4B 00            [ 1]  150 push	#0x00
      008A34 90 89            [ 2]  151 pushw	y
      008A36 CD 8F B1         [ 4]  152 call	__divsint
      008A39 5B 04            [ 2]  153 addw	sp, #4
      008A3B 1F 05            [ 2]  154 ldw	(0x05, sp), x
      008A3D 85               [ 2]  155 popw	x
      008A3E 7B 04            [ 1]  156 ld	a, (0x04, sp)
      008A40 4C               [ 1]  157 inc	a
      008A41 C7 52 1D         [ 1]  158 ld	0x521d, a
      008A44 CC 8A 6D         [ 2]  159 jp	00110$
      008A47                        160 00109$:
      008A47 1E 0A            [ 2]  161 ldw	x, (0x0a, sp)
      008A49 16 08            [ 2]  162 ldw	y, (0x08, sp)
      008A4B 58               [ 2]  163 sllw	x
      008A4C 90 59            [ 2]  164 rlcw	y
      008A4E 89               [ 2]  165 pushw	x
      008A4F 90 89            [ 2]  166 pushw	y
      008A51 1E 07            [ 2]  167 ldw	x, (0x07, sp)
      008A53 89               [ 2]  168 pushw	x
      008A54 1E 07            [ 2]  169 ldw	x, (0x07, sp)
      008A56 89               [ 2]  170 pushw	x
      008A57 CD 8C 67         [ 4]  171 call	__divulong
      008A5A 5B 08            [ 2]  172 addw	sp, #8
      008A5C A3 00 04         [ 2]  173 cpw	x, #0x0004
      008A5F 25 03            [ 1]  174 jrc	00136$
      008A61 CC 8A 67         [ 2]  175 jp	00107$
      008A64                        176 00136$:
      008A64 AE 00 04         [ 2]  177 ldw	x, #0x0004
      008A67                        178 00107$:
      008A67 7B 11            [ 1]  179 ld	a, (0x11, sp)
      008A69 4C               [ 1]  180 inc	a
      008A6A C7 52 1D         [ 1]  181 ld	0x521d, a
      008A6D                        182 00110$:
      008A6D 9F               [ 1]  183 ld	a, xl
      008A6E C7 52 1B         [ 1]  184 ld	0x521b, a
      008A71 9E               [ 1]  185 ld	a, xh
      008A72 5F               [ 1]  186 clrw	x
      008A73 A4 0F            [ 1]  187 and	a, #0x0f
      008A75 1A 05            [ 1]  188 or	a, (0x05, sp)
      008A77 C7 52 1C         [ 1]  189 ld	0x521c, a
      008A7A C6 52 10         [ 1]  190 ld	a, 0x5210
      008A7D AA 01            [ 1]  191 or	a, #0x01
      008A7F C7 52 10         [ 1]  192 ld	0x5210, a
      008A82 7B 0F            [ 1]  193 ld	a, (0x0f, sp)
      008A84 88               [ 1]  194 push	a
      008A85 CD 8A EF         [ 4]  195 call	_I2C_AcknowledgeConfig
      008A88 84               [ 1]  196 pop	a
      008A89 7B 0D            [ 1]  197 ld	a, (0x0d, sp)
      008A8B C7 52 13         [ 1]  198 ld	0x5213, a
      008A8E 7B 10            [ 1]  199 ld	a, (0x10, sp)
      008A90 AA 40            [ 1]  200 or	a, #0x40
      008A92 6B 05            [ 1]  201 ld	(0x05, sp), a
      008A94 4F               [ 1]  202 clr	a
      008A95 97               [ 1]  203 ld	xl, a
      008A96 7B 0C            [ 1]  204 ld	a, (0x0c, sp)
      008A98 A4 03            [ 1]  205 and	a, #0x03
      008A9A 95               [ 1]  206 ld	xh, a
      008A9B A6 80            [ 1]  207 ld	a, #0x80
      008A9D 62               [ 2]  208 div	x, a
      008A9E 9F               [ 1]  209 ld	a, xl
      008A9F 1A 05            [ 1]  210 or	a, (0x05, sp)
      008AA1 C7 52 14         [ 1]  211 ld	0x5214, a
      008AA4                        212 00111$:
      008AA4 5B 05            [ 2]  213 addw	sp, #5
      008AA6 81               [ 4]  214 ret
      008AA7                        215 _I2C_Cmd:
      008AA7 C6 52 10         [ 1]  216 ld	a, 0x5210
      008AAA 0D 03            [ 1]  217 tnz	(0x03, sp)
      008AAC 26 03            [ 1]  218 jrne	00111$
      008AAE CC 8A B9         [ 2]  219 jp	00102$
      008AB1                        220 00111$:
      008AB1 AA 01            [ 1]  221 or	a, #0x01
      008AB3 C7 52 10         [ 1]  222 ld	0x5210, a
      008AB6 CC 8A BE         [ 2]  223 jp	00104$
      008AB9                        224 00102$:
      008AB9 A4 FE            [ 1]  225 and	a, #0xfe
      008ABB C7 52 10         [ 1]  226 ld	0x5210, a
      008ABE                        227 00104$:
      008ABE 81               [ 4]  228 ret
      008ABF                        229 _I2C_GenerateSTART:
      008ABF C6 52 11         [ 1]  230 ld	a, 0x5211
      008AC2 0D 03            [ 1]  231 tnz	(0x03, sp)
      008AC4 26 03            [ 1]  232 jrne	00111$
      008AC6 CC 8A D1         [ 2]  233 jp	00102$
      008AC9                        234 00111$:
      008AC9 AA 01            [ 1]  235 or	a, #0x01
      008ACB C7 52 11         [ 1]  236 ld	0x5211, a
      008ACE CC 8A D6         [ 2]  237 jp	00104$
      008AD1                        238 00102$:
      008AD1 A4 FE            [ 1]  239 and	a, #0xfe
      008AD3 C7 52 11         [ 1]  240 ld	0x5211, a
      008AD6                        241 00104$:
      008AD6 81               [ 4]  242 ret
      008AD7                        243 _I2C_GenerateSTOP:
      008AD7 C6 52 11         [ 1]  244 ld	a, 0x5211
      008ADA 0D 03            [ 1]  245 tnz	(0x03, sp)
      008ADC 26 03            [ 1]  246 jrne	00111$
      008ADE CC 8A E9         [ 2]  247 jp	00102$
      008AE1                        248 00111$:
      008AE1 AA 02            [ 1]  249 or	a, #0x02
      008AE3 C7 52 11         [ 1]  250 ld	0x5211, a
      008AE6 CC 8A EE         [ 2]  251 jp	00104$
      008AE9                        252 00102$:
      008AE9 A4 FD            [ 1]  253 and	a, #0xfd
      008AEB C7 52 11         [ 1]  254 ld	0x5211, a
      008AEE                        255 00104$:
      008AEE 81               [ 4]  256 ret
      008AEF                        257 _I2C_AcknowledgeConfig:
      008AEF C6 52 11         [ 1]  258 ld	a, 0x5211
      008AF2 0D 03            [ 1]  259 tnz	(0x03, sp)
      008AF4 27 03            [ 1]  260 jreq	00119$
      008AF6 CC 8B 01         [ 2]  261 jp	00105$
      008AF9                        262 00119$:
      008AF9 A4 FB            [ 1]  263 and	a, #0xfb
      008AFB C7 52 11         [ 1]  264 ld	0x5211, a
      008AFE CC 8B 23         [ 2]  265 jp	00107$
      008B01                        266 00105$:
      008B01 AA 04            [ 1]  267 or	a, #0x04
      008B03 C7 52 11         [ 1]  268 ld	0x5211, a
      008B06 C6 52 11         [ 1]  269 ld	a, 0x5211
      008B09 88               [ 1]  270 push	a
      008B0A 7B 04            [ 1]  271 ld	a, (0x04, sp)
      008B0C 4A               [ 1]  272 dec	a
      008B0D 84               [ 1]  273 pop	a
      008B0E 26 03            [ 1]  274 jrne	00121$
      008B10 CC 8B 16         [ 2]  275 jp	00122$
      008B13                        276 00121$:
      008B13 CC 8B 1E         [ 2]  277 jp	00102$
      008B16                        278 00122$:
      008B16 A4 F7            [ 1]  279 and	a, #0xf7
      008B18 C7 52 11         [ 1]  280 ld	0x5211, a
      008B1B CC 8B 23         [ 2]  281 jp	00107$
      008B1E                        282 00102$:
      008B1E AA 08            [ 1]  283 or	a, #0x08
      008B20 C7 52 11         [ 1]  284 ld	0x5211, a
      008B23                        285 00107$:
      008B23 81               [ 4]  286 ret
      008B24                        287 _I2C_Send7bitAddress:
      008B24 04 03            [ 1]  288 srl	(0x03, sp)
      008B26 08 03            [ 1]  289 sll	(0x03, sp)
      008B28 7B 03            [ 1]  290 ld	a, (0x03, sp)
      008B2A 1A 04            [ 1]  291 or	a, (0x04, sp)
      008B2C C7 52 16         [ 1]  292 ld	0x5216, a
      008B2F                        293 00101$:
      008B2F 81               [ 4]  294 ret
      008B30                        295 _I2C_SendData:
      008B30 AE 52 16         [ 2]  296 ldw	x, #0x5216
      008B33 7B 03            [ 1]  297 ld	a, (0x03, sp)
      008B35 F7               [ 1]  298 ld	(x), a
      008B36                        299 00101$:
      008B36 81               [ 4]  300 ret
      008B37                        301 _I2C_CheckEvent:
      008B37 52 06            [ 2]  302 sub	sp, #6
      008B39 5F               [ 1]  303 clrw	x
      008B3A 1F 01            [ 2]  304 ldw	(0x01, sp), x
      008B3C 16 09            [ 2]  305 ldw	y, (0x09, sp)
      008B3E 90 A3 00 04      [ 2]  306 cpw	y, #0x0004
      008B42 26 03            [ 1]  307 jrne	00120$
      008B44 CC 8B 4A         [ 2]  308 jp	00121$
      008B47                        309 00120$:
      008B47 CC 8B 56         [ 2]  310 jp	00102$
      008B4A                        311 00121$:
      008B4A C6 52 18         [ 1]  312 ld	a, 0x5218
      008B4D A4 04            [ 1]  313 and	a, #0x04
      008B4F 5F               [ 1]  314 clrw	x
      008B50 97               [ 1]  315 ld	xl, a
      008B51 1F 01            [ 2]  316 ldw	(0x01, sp), x
      008B53 CC 8B 6D         [ 2]  317 jp	00103$
      008B56                        318 00102$:
      008B56 C6 52 17         [ 1]  319 ld	a, 0x5217
      008B59 97               [ 1]  320 ld	xl, a
      008B5A C6 52 19         [ 1]  321 ld	a, 0x5219
      008B5D 95               [ 1]  322 ld	xh, a
      008B5E 4F               [ 1]  323 clr	a
      008B5F 0F 04            [ 1]  324 clr	(0x04, sp)
      008B61 9F               [ 1]  325 ld	a, xl
      008B62 0F 05            [ 1]  326 clr	(0x05, sp)
      008B64 1A 04            [ 1]  327 or	a, (0x04, sp)
      008B66 97               [ 1]  328 ld	xl, a
      008B67 9E               [ 1]  329 ld	a, xh
      008B68 1A 05            [ 1]  330 or	a, (0x05, sp)
      008B6A 95               [ 1]  331 ld	xh, a
      008B6B 1F 01            [ 2]  332 ldw	(0x01, sp), x
      008B6D                        333 00103$:
      008B6D 90 9F            [ 1]  334 ld	a, yl
      008B6F 14 02            [ 1]  335 and	a, (0x02, sp)
      008B71 6B 06            [ 1]  336 ld	(0x06, sp), a
      008B73 90 9E            [ 1]  337 ld	a, yh
      008B75 14 01            [ 1]  338 and	a, (0x01, sp)
      008B77 6B 05            [ 1]  339 ld	(0x05, sp), a
      008B79 93               [ 1]  340 ldw	x, y
      008B7A 13 05            [ 2]  341 cpw	x, (0x05, sp)
      008B7C 26 03            [ 1]  342 jrne	00123$
      008B7E CC 8B 84         [ 2]  343 jp	00124$
      008B81                        344 00123$:
      008B81 CC 8B 89         [ 2]  345 jp	00105$
      008B84                        346 00124$:
      008B84 A6 01            [ 1]  347 ld	a, #0x01
      008B86 CC 8B 8A         [ 2]  348 jp	00106$
      008B89                        349 00105$:
      008B89 4F               [ 1]  350 clr	a
      008B8A                        351 00106$:
      008B8A                        352 00107$:
      008B8A 5B 06            [ 2]  353 addw	sp, #6
      008B8C 81               [ 4]  354 ret
      008B8D                        355 _I2C_GetFlagStatus:
      008B8D 5F               [ 1]  356 clrw	x
      008B8E 16 03            [ 2]  357 ldw	y, (0x03, sp)
      008B90 4F               [ 1]  358 clr	a
      008B91 90 9E            [ 1]  359 ld	a, yh
      008B93 A1 01            [ 1]  360 cp	a, #0x01
      008B95 26 03            [ 1]  361 jrne	00132$
      008B97 CC 8B AB         [ 2]  362 jp	00101$
      008B9A                        363 00132$:
      008B9A A1 02            [ 1]  364 cp	a, #0x02
      008B9C 26 03            [ 1]  365 jrne	00135$
      008B9E CC 8B B2         [ 2]  366 jp	00102$
      008BA1                        367 00135$:
      008BA1 A1 03            [ 1]  368 cp	a, #0x03
      008BA3 26 03            [ 1]  369 jrne	00138$
      008BA5 CC 8B B9         [ 2]  370 jp	00103$
      008BA8                        371 00138$:
      008BA8 CC 8B BD         [ 2]  372 jp	00105$
      008BAB                        373 00101$:
      008BAB C6 52 17         [ 1]  374 ld	a, 0x5217
      008BAE 97               [ 1]  375 ld	xl, a
      008BAF CC 8B BD         [ 2]  376 jp	00105$
      008BB2                        377 00102$:
      008BB2 C6 52 18         [ 1]  378 ld	a, 0x5218
      008BB5 97               [ 1]  379 ld	xl, a
      008BB6 CC 8B BD         [ 2]  380 jp	00105$
      008BB9                        381 00103$:
      008BB9 C6 52 19         [ 1]  382 ld	a, 0x5219
      008BBC 97               [ 1]  383 ld	xl, a
      008BBD                        384 00105$:
      008BBD 7B 04            [ 1]  385 ld	a, (0x04, sp)
      008BBF 89               [ 2]  386 pushw	x
      008BC0 14 02            [ 1]  387 and	a, (2, sp)
      008BC2 85               [ 2]  388 popw	x
      008BC3 4D               [ 1]  389 tnz	a
      008BC4 26 03            [ 1]  390 jrne	00140$
      008BC6 CC 8B CE         [ 2]  391 jp	00107$
      008BC9                        392 00140$:
      008BC9 A6 01            [ 1]  393 ld	a, #0x01
      008BCB CC 8B CF         [ 2]  394 jp	00108$
      008BCE                        395 00107$:
      008BCE 4F               [ 1]  396 clr	a
      008BCF                        397 00108$:
      008BCF                        398 00109$:
      008BCF 81               [ 4]  399 ret
                                    400 .area CODE
                                    401 .area CONST
                                    402 .area INITIALIZER
                                    403 .area CABS (ABS)
