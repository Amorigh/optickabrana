                                      1 .module delay
                                      2 .optsdcc -mstm8
                                      3 .globl _CLK_GetClockFreq
                                      4 .globl _delay_ms
                                      5 .globl _delay_us
                                      6 .area DATA
                                      7 .area INITIALIZED
                                      8 .area DABS (ABS)
                                      9 .area HOME
                                     10 .area GSINIT
                                     11 .area GSFINAL
                                     12 .area CONST
                                     13 .area INITIALIZER
                                     14 .area CODE
                                     15 .area HOME
                                     16 .area GSINIT
                                     17 .area GSFINAL
                                     18 .area GSINIT
                                     19 .area HOME
                                     20 .area HOME
                                     21 .area CODE
      0080E0                         22 _delay_ms:
      0080E0 52 08            [ 2]   23 sub	sp, #8
      0080E2 CD 87 97         [ 4]   24 call	_CLK_GetClockFreq
      0080E5 1F 03            [ 2]   25 ldw	(0x03, sp), x
      0080E7 5F               [ 1]   26 clrw	x
      0080E8 1F 07            [ 2]   27 ldw	(0x07, sp), x
      0080EA 1F 05            [ 2]   28 ldw	(0x05, sp), x
      0080EC 4B 12            [ 1]   29 push	#0x12
      0080EE 5F               [ 1]   30 clrw	x
      0080EF 89               [ 2]   31 pushw	x
      0080F0 4B 00            [ 1]   32 push	#0x00
      0080F2 1E 07            [ 2]   33 ldw	x, (0x07, sp)
      0080F4 89               [ 2]   34 pushw	x
      0080F5 90 89            [ 2]   35 pushw	y
      0080F7 CD 8C 67         [ 4]   36 call	__divulong
      0080FA 5B 08            [ 2]   37 addw	sp, #8
      0080FC 4B E8            [ 1]   38 push	#0xe8
      0080FE 4B 03            [ 1]   39 push	#0x03
      008100 4B 00            [ 1]   40 push	#0x00
      008102 4B 00            [ 1]   41 push	#0x00
      008104 89               [ 2]   42 pushw	x
      008105 90 89            [ 2]   43 pushw	y
      008107 CD 8C 67         [ 4]   44 call	__divulong
      00810A 5B 08            [ 2]   45 addw	sp, #8
      00810C 1F 03            [ 2]   46 ldw	(0x03, sp), x
      00810E 1E 0D            [ 2]   47 ldw	x, (0x0d, sp)
      008110 89               [ 2]   48 pushw	x
      008111 1E 0D            [ 2]   49 ldw	x, (0x0d, sp)
      008113 89               [ 2]   50 pushw	x
      008114 1E 07            [ 2]   51 ldw	x, (0x07, sp)
      008116 89               [ 2]   52 pushw	x
      008117 90 89            [ 2]   53 pushw	y
      008119 CD 8F 35         [ 4]   54 call	__mullong
      00811C 5B 08            [ 2]   55 addw	sp, #8
      00811E 1F 03            [ 2]   56 ldw	(0x03, sp), x
      008120 17 01            [ 2]   57 ldw	(0x01, sp), y
      008122                         58 00103$:
      008122 1E 07            [ 2]   59 ldw	x, (0x07, sp)
      008124 13 03            [ 2]   60 cpw	x, (0x03, sp)
      008126 7B 06            [ 1]   61 ld	a, (0x06, sp)
      008128 12 02            [ 1]   62 sbc	a, (0x02, sp)
      00812A 7B 05            [ 1]   63 ld	a, (0x05, sp)
      00812C 12 01            [ 1]   64 sbc	a, (0x01, sp)
      00812E 25 03            [ 1]   65 jrc	00118$
      008130 CC 81 43         [ 2]   66 jp	00105$
      008133                         67 00118$:
      008133 9D               [ 1]   68 nop
      008134 1E 07            [ 2]   69 ldw	x, (0x07, sp)
      008136 5C               [ 1]   70 incw	x
      008137 1F 07            [ 2]   71 ldw	(0x07, sp), x
      008139 26 05            [ 1]   72 jrne	00119$
      00813B 1E 05            [ 2]   73 ldw	x, (0x05, sp)
      00813D 5C               [ 1]   74 incw	x
      00813E 1F 05            [ 2]   75 ldw	(0x05, sp), x
      008140                         76 00119$:
      008140 CC 81 22         [ 2]   77 jp	00103$
      008143                         78 00105$:
      008143 5B 08            [ 2]   79 addw	sp, #8
      008145 81               [ 4]   80 ret
      008146                         81 _delay_us:
      008146 52 08            [ 2]   82 sub	sp, #8
      008148 CD 87 97         [ 4]   83 call	_CLK_GetClockFreq
      00814B 1F 03            [ 2]   84 ldw	(0x03, sp), x
      00814D 5F               [ 1]   85 clrw	x
      00814E 1F 07            [ 2]   86 ldw	(0x07, sp), x
      008150 1F 05            [ 2]   87 ldw	(0x05, sp), x
      008152 4B 12            [ 1]   88 push	#0x12
      008154 5F               [ 1]   89 clrw	x
      008155 89               [ 2]   90 pushw	x
      008156 4B 00            [ 1]   91 push	#0x00
      008158 1E 07            [ 2]   92 ldw	x, (0x07, sp)
      00815A 89               [ 2]   93 pushw	x
      00815B 90 89            [ 2]   94 pushw	y
      00815D CD 8C 67         [ 4]   95 call	__divulong
      008160 5B 08            [ 2]   96 addw	sp, #8
      008162 4B E8            [ 1]   97 push	#0xe8
      008164 4B 03            [ 1]   98 push	#0x03
      008166 4B 00            [ 1]   99 push	#0x00
      008168 4B 00            [ 1]  100 push	#0x00
      00816A 89               [ 2]  101 pushw	x
      00816B 90 89            [ 2]  102 pushw	y
      00816D CD 8C 67         [ 4]  103 call	__divulong
      008170 5B 08            [ 2]  104 addw	sp, #8
      008172 1F 03            [ 2]  105 ldw	(0x03, sp), x
      008174 17 01            [ 2]  106 ldw	(0x01, sp), y
      008176 4B E8            [ 1]  107 push	#0xe8
      008178 4B 03            [ 1]  108 push	#0x03
      00817A 5F               [ 1]  109 clrw	x
      00817B 89               [ 2]  110 pushw	x
      00817C 1E 11            [ 2]  111 ldw	x, (0x11, sp)
      00817E 89               [ 2]  112 pushw	x
      00817F 1E 11            [ 2]  113 ldw	x, (0x11, sp)
      008181 89               [ 2]  114 pushw	x
      008182 CD 8C 67         [ 4]  115 call	__divulong
      008185 5B 08            [ 2]  116 addw	sp, #8
      008187 89               [ 2]  117 pushw	x
      008188 90 89            [ 2]  118 pushw	y
      00818A 1E 07            [ 2]  119 ldw	x, (0x07, sp)
      00818C 89               [ 2]  120 pushw	x
      00818D 1E 07            [ 2]  121 ldw	x, (0x07, sp)
      00818F 89               [ 2]  122 pushw	x
      008190 CD 8F 35         [ 4]  123 call	__mullong
      008193 5B 08            [ 2]  124 addw	sp, #8
      008195 1F 03            [ 2]  125 ldw	(0x03, sp), x
      008197 17 01            [ 2]  126 ldw	(0x01, sp), y
      008199                        127 00103$:
      008199 1E 07            [ 2]  128 ldw	x, (0x07, sp)
      00819B 13 03            [ 2]  129 cpw	x, (0x03, sp)
      00819D 7B 06            [ 1]  130 ld	a, (0x06, sp)
      00819F 12 02            [ 1]  131 sbc	a, (0x02, sp)
      0081A1 7B 05            [ 1]  132 ld	a, (0x05, sp)
      0081A3 12 01            [ 1]  133 sbc	a, (0x01, sp)
      0081A5 25 03            [ 1]  134 jrc	00118$
      0081A7 CC 81 BA         [ 2]  135 jp	00105$
      0081AA                        136 00118$:
      0081AA 9D               [ 1]  137 nop
      0081AB 1E 07            [ 2]  138 ldw	x, (0x07, sp)
      0081AD 5C               [ 1]  139 incw	x
      0081AE 1F 07            [ 2]  140 ldw	(0x07, sp), x
      0081B0 26 05            [ 1]  141 jrne	00119$
      0081B2 1E 05            [ 2]  142 ldw	x, (0x05, sp)
      0081B4 5C               [ 1]  143 incw	x
      0081B5 1F 05            [ 2]  144 ldw	(0x05, sp), x
      0081B7                        145 00119$:
      0081B7 CC 81 99         [ 2]  146 jp	00103$
      0081BA                        147 00105$:
      0081BA 5B 08            [ 2]  148 addw	sp, #8
      0081BC 81               [ 4]  149 ret
                                    150 .area CODE
                                    151 .area CONST
                                    152 .area INITIALIZER
                                    153 .area CABS (ABS)
