                                      1 .module stm8s_uart1
                                      2 .optsdcc -mstm8
                                      3 .globl _CLK_GetClockFreq
                                      4 .area DATA
                                      5 .area INITIALIZED
                                      6 .area DABS (ABS)
                                      7 .area HOME
                                      8 .area GSINIT
                                      9 .area GSFINAL
                                     10 .area CONST
                                     11 .area INITIALIZER
                                     12 .area CODE
                                     13 .area HOME
                                     14 .area GSINIT
                                     15 .area GSFINAL
                                     16 .area GSINIT
                                     17 .area HOME
                                     18 .area HOME
                                     19 .area CODE
                                     20 .area CODE
                                     21 .area CONST
                                     22 .area INITIALIZER
                                     23 .area CABS (ABS)
